#include<stdio.h>
#include"ftp.h"


int main()
{
    char tempIP[16] = "200.200.4.216";
    unsigned short port = 21;
    char usrname[] = "tzw";
    char pwd[] = "123456";
    char remote_path[256] = "/newtest/cool.zip";
    char local_path[256] = "./testfile/cool.zip";
    FTP* ftp=new FTP;
    ftp->set_addr(tempIP,port);
    ftp->set_user(usrname,strlen(usrname));
    ftp->set_pwd(pwd,strlen(pwd));
    ftp->set_remotedir(remote_path,strlen(remote_path));
    ftp->set_localdir(local_path,strlen(local_path));
    bool Stop_upgrade=false;
    //上传
    #if 1
    if(ftp->open_ftp())
    {
        if(ftp-> into_passive())
        {
            printf("into PASV success\n");
            if(!ftp->upload())
            {
              //  reply_server_func(msg,msglen,0x04);//0x04 upload fail
                ftp->close_ftp();
                if(ftp)
                {
                    delete ftp;
                    ftp = NULL;
                }   
                return 0;
            }
            else
            {
                printf("upload success\n");
            }
        }
    }
    else
    {
        ftp->close_ftp();
    }
    if(ftp)
    {
        delete ftp;
        ftp = NULL;
    } 
    #endif 

    //下载

    
    return 0;
}