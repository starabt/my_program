#ifndef _TESTPACK_H
#define _TESTPACK_H

#include <stdio.h>
#include <string.h>
#include <netinet/in.h>
#include <time.h>
#include "global.h"

void test1_datapack(int clientfd);//5
void test2_datapack(int clientfd);//6
void test3_datapack(int clientfd);//7
void test4_datapack(int clientfd);//8
void test5_datapack(int clientfd);//9

#endif