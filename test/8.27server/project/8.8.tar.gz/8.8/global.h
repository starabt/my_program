#ifndef _GLOBAL_H_
#define _GLOBAL_H_

#include <resolv.h>

//命令标识
#define command_login 0x01
#define command_logout 0x04
#define command_data 0x02
#define command_time 0x08
#define command_heartbeat 0x07
#define command_modify_heartbeat_time 0x09
#define respond_param_query 0x80
#define respond_param_set 0x81
//应答标识
#define respond_success 0x01
#define respond_fail 0x02
#define respond_vin_repeat 0x03
#define respond_command 0xfe

#define car_data 0x01
#define motor_data 0x02
#define battery_data 0x03
#define engine_data 0x04
#define car_location_data 0x05
#define extremum_data 0x06
#define alarm_data 0x07

#define data_buffer_length 10*1024//数据缓冲区长度
#define BACKLOG 5 
#define clientfds_max 50 
#define MAXBUF 1024//最大数据长度
#define vin_database_number 4//vin数据库数量
#define heartbeat_count_max 3
#define data_timeout 5//数据处理超时时间(s)

extern int clientfds[clientfds_max];//客户端的socketfd,50个元素，fds[0]~fds[49]

#endif