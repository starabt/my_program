/*********************解析数据（保存和打印函数）**************************/
#ifndef _PARSE_DATA_H_
#define _PARSE_DATA_H_

#include "global.h"
#include "clientfd.h"
#include <string.h>
#include <stdio.h>

#define car_data 0x01
#define motor_data 0x02
#define battery_data 0x03
#define engine_data 0x04
#define car_location_data 0x05
#define extremum_data 0x06
#define alarm_data 0x07

int save_car_data(unsigned char data[], int data_start_bit, int clientfd);
int save_battery_data(unsigned char data[], int data_start_bit, int clientfd);
int save_extremum_data(unsigned char data[], int data_start_bit, int clientfd);
int save_alarm_data(unsigned char data[], int data_start_bit, int clientfd);

void printf_car_data(int clientfd);
void printf_battery_data(int clientfd);
void printf_alarm_data(int clientfd);
void printf_extremum_data(int clientfd);

void printf_time(unsigned char data[]);

#endif