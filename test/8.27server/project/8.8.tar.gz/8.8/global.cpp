#include "global.h"

int clientfds[clientfds_max] = {0};