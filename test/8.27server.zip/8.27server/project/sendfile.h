#ifndef _SENDFILE_H_
#define  _SENDFILE_H_

#include "global.h"

void process_conn_client(int s);

#endif