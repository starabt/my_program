//初始化
#include "tcp_client.h"
int sockfd, len,len2,control_sockfd;
char *IP=new char [100];
char *port=new char [50];
struct sockaddr_in dest;
unsigned char buffer[MAXBUF + 1];
unsigned char buffer2[MAXBUF + 1];
unsigned char buf_packet[10240];
unsigned char buffer_joint[MAXBUF+1];
unsigned char data_head[MAXBUF+1];
unsigned char ary2[MAXBUF+1];
bool loop1= 1;
bool loop2= 1;
int login_num=1;
int datasend_time=7;
int heartbeat_time=30;
int tcp_check=0;
int data_count=0;
int loop_30s_send=30;
int buf_bit=0;
int connect_again_sign = 0;
parameter car_parameter;
List * alarmhead;
List * sendhead;
SList * recvhead;
pthread_attr_t attr;
timer_t data_timer, heartbeat_timer;
struct sigevent data_evp, heartbeat_evp;
Log log;
TCP_CLIENT tcp_client;

/************************************************************
*func:		keyboard_send()
*param:	
*descrp:	check the keyboard
*author:	Darren
*date:		2019.7.16
*ver:		v1.0.0
*change:
************************************************************/
void *keyboard_send(void *)
{	
	while(loop1)
    {
    	char  keyboard_order[MAXBUF];
		printf("order(1:login;  2:logout;  3:set data sending time;	4:set heartbeat time;\n5:alarm;   6:upload log;  0:exit;	\n");
		cin>>keyboard_order;
		if (strcmp("1",keyboard_order) == 0){
			printf("logging in...\n");
			tcp_client.log_in();
			tcp_client.time_check();
			tcp_client.modify_heartbeat_time();//初始化心跳间隔
		}
		if (strcmp("2",keyboard_order) == 0){
			printf("logging out...\n");
			tcp_client.log_out();
		}
		if (strcmp("3",keyboard_order) == 0){
			printf("输入需要实时数据上报间隔(s)\n");
			scanf("%d",&datasend_time); 
			car_parameter.normal_time_period=datasend_time;
		}
		if (strcmp("4",keyboard_order) == 0){
			printf("输入需要心跳间隔(s)\n");
			scanf("%d",&heartbeat_time); 
			car_parameter.heartbeat_send_period=heartbeat_time;
			tcp_client.modify_heartbeat_time();
			tcp_client.heartbeat_send();
		}
		if (strcmp("5",keyboard_order) == 0){
			tcp_client.send_previous_data();
			loop_30s_send=0;
		}
		if (strcmp("6",keyboard_order) == 0){
			char filename[60];
			bzero(filename,60);
			if (-1 != tcp_client.select_log_filename(filename))
			{
				tcp_client.send_log_upload();
				void *process_tcp_upload(void*uf);
				printf("filename is %s\n", filename);
				pthread_t upload;
				printf("create upload pthread\n");
				pthread_create(&upload,NULL,process_tcp_upload,&filename);
				usleep(1);
			}
		}
		if (strcmp("11",keyboard_order) == 0){
			test1();
		}
		if (strcmp("12",keyboard_order) == 0){
			test2();
		}
		if (strcmp("13",keyboard_order) == 0){
			test3();
		}
		if (strcmp("14",keyboard_order) == 0){
			test4();
		}
		if (strcmp("15",keyboard_order) == 0){
			test5();
		}
		if (strcmp("16",keyboard_order) == 0){
			test6();//测试实时数据补发
		}
		if (strcmp("0",keyboard_order) == 0){
			loop1=0;
			loop2=0;
			timer_delete(data_timer);
			timer_delete(heartbeat_timer);
		}
		usleep(2000);
	}
	return NULL;
}

/************************************************************
*func:		dispose_sendbuf()
*param:	
*descrp:	begin to send messages
*author:	Darren
*date:		2019.7.16
*ver:		v1.0.0
*change:
************************************************************/
void *dispose_sendbuf(void *)
{
	while(loop1)
	{
		if (connect_again_sign==-1)
		{
			while(1)
			{
				if (connect_again_sign == 1 )
				{
					break;
				}
				usleep(200);
			}
		}
		tcp_client.deal_buftosend();
		usleep(200);
	}
	return NULL;
}

/************************************************************
*func:		dispose_recvbuf()
*param:	
*descrp:	begin to send messages
*author:	Darren
*date:		2019.8.8
*ver:		v1.0.0
*change:
************************************************************/
void *dispose_recvbuf(void *)
{
	while(loop2)
	{
		tcp_client.deal_recvbuf();
	}
	return NULL;
}

/************************************************************
*func:		receive_message()
*param:
*descrp:	receive messages from the server
*author:	Darren
*date:		2019.7.16
*ver:		v1.0.0
*change:
************************************************************/
void *receive_message(void *)
{
	while(loop2)
    {
		bzero(buffer2, MAXBUF + 1);
		if(sockfd==-1)
		{
			printf("socket is disconnect \n");
			printf("tcp_recv thread is ready to quit \n");
			loop2=0;
			loop1=0;
		}
		len2 = recv(sockfd, buffer2, MAXBUF+1, 0);
		printf("len2:%d\n",len2 );
		if(len2 > 0)
		{
			tcp_client.send_recvbuf(buffer2,len2);
		}
		else if(len2 < 0)
		{
			perror("recv");
		}
		else
		{
			printf("the server close ,quit\n");
			loop1=0;
			loop2=0;
		}
	}
    return NULL;
}

/************************************************************
*func:		datasend_timeout()
*param:		union sigval v
*descrp:	control datasend
*author:	Darren
*date:		2019.7.20
*ver:		v1.0.0
*change:
************************************************************/
static void datasend_timeout(union sigval v)
{
	extern TCP_CLIENT tcp_client;
	data_count++;
	time_t t;
	char p[32];
	timer_t *q;
	struct itimerspec ts;
	int ret;
	time(&t);
	strftime(p, sizeof(p), "%T", localtime(&t));
	tcp_client.data_save(tcp_client.data_create());
	if (data_count>=datasend_time)
	{
		log.save_normal_log(tcp_client.data_create());
		if(connect_again_sign==-1)
		{
			data_count = 0;
			tcp_client.datasave_abnormal(tcp_client.data_create());
		}
		else
		{
			data_count=0;
			tcp_client.send_data(tcp_client.data_create());
		}
	}
	if (loop_30s_send<30)
	{
		tcp_client.send_data(tcp_client.data_create());
		loop_30s_send++;
	}
	q = (timer_t *)(v.sival_ptr);
	ts.it_interval.tv_sec = 0;
	ts.it_interval.tv_nsec = 0;
	ts.it_value.tv_sec = 1;
	ts.it_value.tv_nsec = 0;
	ret = timer_settime(*q, CLOCK_REALTIME, &ts, NULL);
	if (ret != 0) {
		printf("settime err(%d)!\n", ret);
	}
}

/************************************************************
*func:		heartbeat_timeout()
*param:		union sigval v
*descrp:	control heartbeat
*author:	Darren
*date:		2019.7.20
*ver:		v1.0.0
*change:
************************************************************/
static void heartbeat_timeout(union sigval v)
{
	extern TCP_CLIENT tcp_client;
	time_t t;
	char p[32];
	timer_t *q;
	struct itimerspec ts;
	int ret;
	time(&t);
	strftime(p, sizeof(p), "%T", localtime(&t));
	tcp_client.heartbeat_send();
	tcp_check++;
	if (tcp_check==3)
	{	
		printf("网络异常!\n");
		for(int count=60; count!=0; count--)
		{
			sleep(1);
			connect_again_sign=-1;
			close(sockfd);
			if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) 
		    {
		        perror("Socket");
		        char tmp_log[256];
		        sprintf(tmp_log,"%s%s","Socket create error:",strerror(errno));
		        tcp_client.save_error_log(tmp_log);
		        exit(errno);
		    }
		    bzero(&dest, sizeof(dest));
			dest.sin_family = AF_INET;
			dest.sin_port = htons(atoi(port));
			if(inet_aton(IP, (struct in_addr *) &dest.sin_addr.s_addr) == 0)
			{
				perror(IP);
				char tmp_log2[256];
		        sprintf(tmp_log2,"%s%s","Socket init error:",strerror(errno));
		        tcp_client.save_error_log(tmp_log2);
				exit(errno);
			}
			if(connect(sockfd, (struct sockaddr *) &dest, sizeof(dest))==-1)
			{
				printf("connect failed,try again\n");
			}
			else{
				printf("网络重连成功！\n");
				connect_again_sign=1;
				tcp_client.log_in();
				tcp_client.modify_heartbeat_time();
				pthread_t t5;
				void *datasend_abnormal(void *);
				pthread_create(&t5,NULL,datasend_abnormal,(void*)0);
				break;
			}
		}
		if (connect_again_sign==-1)
		{
			loop1=0;
			loop2=0;
			char tmp_log3[256];
	        sprintf(tmp_log3,"%s%s","Socket init error:",strerror(errno));
	        tcp_client.save_error_log(tmp_log3);
			tcp_client.close_socket();
			exit(0);
		}
	}
	q = (timer_t *)(v.sival_ptr);
	ts.it_interval.tv_sec = 0;
	ts.it_interval.tv_nsec = 0;
	ts.it_value.tv_sec = heartbeat_time;
	ts.it_value.tv_nsec = 0;
	ret = timer_settime(*q, CLOCK_REALTIME, &ts, NULL);
	if (ret != 0) {
		printf("settime err(%d)!\n", ret);
	}
}

/************************************************************
*func:		TCP_CLIENT()
*param:		
*descrp:	init partly
*author:	Darren
*date:		2019.7.22
*ver:		v1.0.0
*change1:	delete	void par_init()
					{
						car_parameter.time_period = 0x1b58;
						car_parameter.normal_time_period=datasend_time;
						car_parameter.alarm_time_period=0x7d0;
						car_parameter.domain_name_length=4;
						car_parameter.domain_name[0]=192;
						car_parameter.domain_name[1]=168;
						car_parameter.domain_name[2]=43;
						car_parameter.domain_name[3]=249;
						car_parameter.tcp_port=3456;
						char *v1="1.0.1";
						memcpy(car_parameter.hardware_version,v1,5*sizeof(char));
						char *v2="1.0.0";
						memcpy(car_parameter.firmware_version,v1,5*sizeof(char));
						car_parameter.heartbeat_send_period=heartbeat_time;
						car_parameter.respond_overtime_time=1800;
						car_parameter.platform_overtime_time=1800;
						car_parameter.gap_login_time=60;
						car_parameter.common_domain_name_length=4;
						car_parameter.common_domain_name[0]=192;
						car_parameter.common_domain_name[1]=168;
						car_parameter.common_domain_name[2]=43;
						car_parameter.common_domain_name[3]=222;
						car_parameter.common_tcp_port=10222;
						car_parameter.sampling_inspection=1;
					}
			use file to init instead;
************************************************************/
TCP_CLIENT::TCP_CLIENT()
{
	FILE *fp ;
	fp=fopen("car_data" , "rb" );
	if ( fp == NULL )
	{
		printf("打开car_data存储文件失败！\n");
		exit(0);
	}
	fread( (char*)(&car_parameter) , sizeof(parameter), 1 , fp ); //从文件中读结构体的数据
	fclose(fp);
	alarmhead = new List;            //初始化报警数据存储区
	bzero(alarmhead->tcp_data,MAXBUF+1);               //将头结点的数据域定义为0
	alarmhead->next = NULL;            //头结点的下一个定义为NULL
	sendhead = new List;           //初始化基于链队列的发送缓冲区
	bzero(sendhead->tcp_data,MAXBUF+1);               
	sendhead->next = NULL;
	recvhead = new SList;           //初始化基于链队列的接收缓冲区
	bzero(recvhead->recv_data,MAXBUF+1);
	recvhead->recv_len=0;               
	recvhead->next = NULL;
}

/************************************************************
*func:		TCP_CLIENT()
*param:		
*descrp:	init partly
*author:	Darren
*date:		2019.7.22
*ver:		v1.0.0
************************************************************/
TCP_CLIENT::~TCP_CLIENT()
{
	 printf("quit TCP!");
	 delete IP;
	 delete port;
}

/************************************************************
*func:		set_socket(argc,argv)
*param:		ip_address port 
*descrp:	set sockets
*author:	Darren
*date:		2019.7.11
*ver:		v1.0.0
*change:        
************************************************************/
void TCP_CLIENT::set_socket(int argc,char **argv)
{
    if (argc != 3)
    {
        printf(" error format,it must be:\n\t\t%s IP port\n",argv[0]);
        exit(EXIT_FAILURE);
    }
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) 
    {
        perror("Socket");
        char tmp_log[256];
        sprintf(tmp_log,"%s%s","create socket error:",strerror(errno));
        save_error_log(tmp_log);
        exit(errno);
    }
    printf("socket created\n");
}

/************************************************************
*func:		connect_socket(argv)
*param:		port
*descrp:	connect
*author:	Darren
*date:		2019.7.11
*ver:		v1.0.0
*change1:	
		*descrp:	add the function of connecting again during the failure of connecting
		*author:	Darren
		*date:		2019.7.15
		*ver:		v1.1.0	
************************************************************/
void TCP_CLIENT::connect_socket(char **argv)
{
	bzero(&dest, sizeof(dest));
	dest.sin_family = AF_INET;
	dest.sin_port = htons(atoi(argv[2]));
	if(inet_aton(argv[1], (struct in_addr *) &dest.sin_addr.s_addr) == 0)
	{
		perror(argv[1]);
		char tmp_log[256];
        sprintf(tmp_log,"%s%s","init socket error:",strerror(errno));
        save_error_log(tmp_log);
		exit(errno);
	}
	if(connect(sockfd, (struct sockaddr *) &dest, sizeof(dest))==-1)
	{
		printf("connect failed,try again\n");
		sleep(2);
		close(sockfd);
		if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) 
	    {
	        perror("Socket");
	        char tmp_log2[256];
	        sprintf(tmp_log2,"%s%s","create socket error:",strerror(errno));
	        save_error_log(tmp_log2);
	        exit(errno);
	    }
		bzero(&dest, sizeof(dest));
		dest.sin_family = AF_INET;
		dest.sin_port = htons(atoi(argv[2]));
		if(inet_aton(argv[1], (struct in_addr *) &dest.sin_addr.s_addr) == 0)
		{
			perror(argv[1]);
			char tmp_log3[256];
	        sprintf(tmp_log3,"%s%s","init socket error:",strerror(errno));
	        save_error_log(tmp_log3);
			exit(errno);
		}

		if(connect(sockfd, (struct sockaddr *) &dest, sizeof(dest))==-1){
			printf("connect failed\n");
			perror("Connect ");
			char tmp_log4[256];
	        sprintf(tmp_log4,"%s%s","Connect error:",strerror(errno));
	        save_error_log(tmp_log4);
			exit(errno);
		}
	}
	printf("server connected\n");
	return;
}


/************************************************************
*func:		send_recvbuf()
*param:	
*descrp:	send message to the buffer 
*author:	Darren
*date:		2019.8.7
*ver:		v1.0.0
*change:
************************************************************/
void TCP_CLIENT::send_recvbuf(unsigned char bufferc[],int lenr)
{
	SList buftorecv;
	memcpy(buftorecv.recv_data,bufferc,MAXBUF+1);
	buftorecv.recv_len=lenr;
	SList * newNode = new SList;    //定义一个Node结点指针newNode
	memcpy(newNode->recv_data,buftorecv.recv_data,MAXBUF+1);
	newNode->recv_len = buftorecv.recv_len;
	SList * q = recvhead;              //定义指针p指向头结点
	if (recvhead == NULL) {           //当头结点为空时，设置newNode为头结点
	    recvhead = newNode;
	}
	newNode->next = q->next;          //将新节点插入到头部
	q->next = newNode;
}


/************************************************************
*func:		deal_recvbuf()
*param:	
*descrp:	deal with the received buffer message 
*author:	Darren
*date:		2019.8.7
*ver:		v1.0.0
*change:
************************************************************/
void TCP_CLIENT::deal_recvbuf()
{
	SList * q = recvhead;          //创建一个指针指向头结点
	SList * qtemp = NULL;      //创建一个占位节点
	if (q->next == NULL) {        //判断链表是否为空
		return;
	}
	else
	{
		while (q->next != NULL)   //循环到尾部的前一个
		{
			qtemp = q;            //将ptemp指向尾部的前一个节点
			q = q->next;          //p指向最后一个节点
		}
		begin_analyse(q->recv_data,q->recv_len);
		delete q;                //删除尾部节点
		q = NULL;
		qtemp->next = NULL;
	}
}

/************************************************************
*func:		begin_analyse()
*param:	
*descrp:	begin to analyse packets
*author:	Darren
*date:		2019.8.1
*ver:		v1.0.0
*change:
************************************************************/
void TCP_CLIENT::begin_analyse(unsigned char buffera[],int lena)
{
	for (buf_bit=0; buf_bit<MAXBUF-1; buf_bit++)
	{
		if (buffera[buf_bit+1]==0x23 && buffera[buf_bit]==0x23)
		{
			if (pick_single_packet(buffera,lena)==0)
			{
				analyse_single_packet(buf_packet);
			}
		}
	}
}
/************************************************************
*func:		pick_single_packet()
*param:	
*descrp:	pick a packet
*author:	Darren
*date:		2019.7.31
*ver:		v1.0.0
*change:
************************************************************/
int TCP_CLIENT::pick_single_packet(unsigned char buffera[],int lenp)
{
	int buf_data_num;
	buf_data_num=((buffera[22+buf_bit]<<8)+buffera[23+buf_bit]+25);
	if (buf_data_num==0xFFFF)
		return -1;
	printf("报文长度：%d\n",buf_data_num );
	bzero(buf_packet,10240);
	int count,point;
	if(buf_data_num<=MAXBUF+1-buf_bit)
	{
		if(buffera[buf_data_num+buf_bit-1]!=0)
		{
			memcpy(buf_packet,buffera+buf_bit,buf_data_num);
			return 0;//完整的包(BCC不一定对）
		}
		else//不完整，拼包
		{
			printf("进入拼包\n");
			for(count=MAXBUF; buffera[count-1]==0; count--){}
			printf("开始拼包\n");
			if ((count-buf_bit)<buf_data_num)
			{
				int short_joint_exist=count-buf_bit;
				int short_joint_left=buf_data_num-short_joint_exist;
				printf("拼第一个包\n");
				memcpy(buf_packet,buffera+buf_bit,short_joint_exist);
				printf("拼第一个包完成\n");
				for(point=1;short_joint_left>0;short_joint_left=short_joint_left-short_joint_exist)
				{
					int recvbuf_len = recvbuf_GetLength();
					printf("查询缓存区存储个数完成，为%d\n",recvbuf_len);
					point=1;
					if (recvbuf_len<= point)
					{
						printf("缓存区无多余数据包！\n");
						return -1;
					}
					get_recvbuf(recvbuf_len-point);
					if ((buffer_joint[1]!=0x23||buffer_joint[0]!=0x23))
					{
						printf("拼一次包\n");
						for(count=MAXBUF; buffera[count]==0; count--){}
						short_joint_exist = count + 1;
						memcpy(buf_packet+buf_data_num-short_joint_left,buffer_joint,short_joint_left);
					}
					else
					{
						printf("下一包为新包\n");
						return -1;
					}
				}
				printf("**************拼包完成！*************\n");
				return 0;
			}
			printf("拼包失败\n");
			return -1;
		}
	}
	else if (buf_data_num>MAXBUF+1-buf_bit)//包的数据位过长
	{
		if (buf_data_num>10240)
		{
			return -1;
		}
		int count;
		for(count=1024; buffera[count]==0; count--){
		}
		printf("此包中数据有%d位\n",count+1);
		printf("最后一位：%d\n",buffera[count]);
		usleep(2000);
		int recvbuf_len=recvbuf_GetLength();
		int least_joint_time = ((buf_data_num-(count - buf_bit + 1))/1025) +1;
		printf("此包中数据有%d位\n",(count+1));
		printf("开头位：%d\n",buffera[0]);
		printf("512位：%d\n",buffera[512]);
		printf("513位：%d\n",buffera[513]);
		printf("最后位：%d\n",buffera[MAXBUF]);
		printf("查询缓存区存储个数完成，为%d\n",recvbuf_len);
		if (recvbuf_len <= least_joint_time)
		{
			printf("数据长度位错误！\n");
			return -1;
		}
		printf("进入拼包\n");
		if ((count-buf_bit+1)<buf_data_num)
		{
			int long_joint_exist=count-buf_bit+1;
			int long_joint_left=buf_data_num-long_joint_exist;
			printf("拼第一个包\n");
			memcpy(buf_packet,buffera+buf_bit,long_joint_exist);
			printf("拼第一个包完成\n");
			for(point=1;long_joint_left>0;long_joint_left=long_joint_left-long_joint_exist,point++)
			{
				int recvbuf_len=recvbuf_GetLength();
				printf("查询缓存区存储个数完成，为%d\n",recvbuf_len);
				printf("point:%d\n",point);
				if (recvbuf_len<= point)
				{
					printf("缓存区无多余数据包！\n");
					return -1;
				}
				get_recvbuf(recvbuf_len-point);
				if ((buffer_joint[1]!=0x23||buffer_joint[0]!=0x23))
				{
					printf("拼一次包\n");
					for(count=1024; buffer_joint[count]==0; count--){}
					long_joint_exist = count+1;
					printf("此包中数据有%d位\n",long_joint_exist);
					printf("开头位：%d\n",buffer_joint[0]);
					printf("中间位：%d\n",buffer_joint[513]);
					printf("最后位：%d\n",buffer_joint[1024]);
					memcpy(buf_packet+buf_data_num-long_joint_left,buffer_joint,long_joint_left);
				}
				else
				{
					printf("下一包为新包\n");
					return -1;
				}
			}
			printf("**************拼包完成！*************\n");
			return 0;
		}
		printf("拼包失败\n");
		return -1;
	}
}

/************************************************************
*func:		recvbuf_GetLength()
*param:	
*descrp:	获取接收缓冲区长度
*author:	Darren
*date:		2019.8.8
*ver:		v1.0.0
*change:
************************************************************/
int TCP_CLIENT::recvbuf_GetLength()
{

    int count_len = 0;                  //定义count计数
    SList *s = recvhead->next;           //定义p指向头结点
    while (s != NULL)                //当指针的下一个地址不为空时，count+1
    {
        count_len++;                  
        s = s->next;                //p指向p的下一个地址
    }
    return count_len;                   //返回count的数据
}

/************************************************************
*func:		unsigned char *get_recvbuf()
*param:		int n
*descrp:	获取接收缓冲区长度
*author:	Darren
*date:		2019.8.8
*ver:		v1.0.0
*change:
************************************************************/
void TCP_CLIENT::get_recvbuf(int n)
{ 
	printf("********拼包中********\n");
    SList * p = recvhead;                    //创建一个指针指向头结点
    int i = 0;
    while (n > i)                           //遍历到指定的位置
    {
        p = p->next;
        i++;
    }
    bzero(buffer_joint,MAXBUF+1);
    memcpy(buffer_joint,p->recv_data,MAXBUF+1);
}

/************************************************************
*func:		analyse_single_packet()
*param:		unsigned char bufferb[]
*descrp:	analyse a packet
*author:	Darren
*date:		2019.7.30
*ver:		v1.0.0
*change:
************************************************************/
int TCP_CLIENT::analyse_single_packet(unsigned char bufferb[])
{
	int order_sign;
	int buf_data_num=((bufferb[22]<<8)+bufferb[23]+25);
	if (buf_data_num>10240)
	{
		return -1;
		printf("***********数据长度位错误，返回解析***********\n");
	}
	int m=buf_bit;
	buf_bit=0;
	if (BCC_check(bufferb) == true)//数据校验成功，进入数据处理
	{
		buf_bit += (buf_data_num-1);
		order_sign = bufferb[2];
		switch(order_sign)	
		{
			case 0x01:	respond_login(bufferb);break;//登入回复
			case 0x02:	respond_data(bufferb);break;//实时信息上报回复
			case 0x03:	respond_reissue(bufferb);break;//补发信息回复
			case 0x04:	respond_logout(bufferb);
						close_socket();
						break;//登出回复
			case 0x07:respond_heartbeat(bufferb);break;//心跳回复
			case 0x08:respond_time(bufferb);break;//终端校时回复
			case 0x09:respond_modify_heartbeat(bufferb);break;//终端校时回复
			case 0x80:respond_inquire(bufferb);break;//查询参数回复
			case 0x81:respond_set_parameter(bufferb);break;//设置参数回复
			case 0x82:respond_upgrade(bufferb);break;//升级
			default:printf("未知命令！\n");
		}
	}
	else
	{
		printf("鉴别失败！\n");
		printf("BCC校验位：%d\n",bufferb[buf_data_num-1]);
		/*for(k=0;k<buf_data_num;k++)
		{
			printf("%x\n",bufferb[k]);
		}*/
	}
	buf_bit=m;
	return buf_data_num;
}

/************************************************************
*func:		send_buftosend()
*param:	
*descrp:	send message to the buffer 
*author:	Darren
*date:		2019.8.7
*ver:		v1.0.0
*change:
************************************************************/
//把数据存储到缓冲区（在头部插入）
void TCP_CLIENT::send_buftosend(unsigned char buffers[])
{
	List buftosend;
	memcpy(buftosend.tcp_data,buffers,MAXBUF+1);
	List * newNode = new List;    //定义一个Node结点指针newNode
	memcpy(newNode->tcp_data,buftosend.tcp_data,MAXBUF+1);
	List * p = sendhead;              //定义指针p指向头结点
	if (sendhead == NULL) {           //当头结点为空时，设置newNode为头结点
	    sendhead = newNode;
	}
	newNode->next = p->next;          //将新节点插入到头部
	p->next = newNode;
}

/************************************************************
*func:		deal_buftosend()
*param:	
*descrp:	deal with the buffer message 
*author:	Darren
*date:		2019.8.7
*ver:		v1.0.0
*change:
************************************************************/
void TCP_CLIENT::deal_buftosend()
{
	List * p = sendhead;          //创建一个指针指向头结点
	List * ptemp = NULL;      //创建一个占位节点
	if (p->next == NULL) {        //判断链表是否为空
		return;
	}
	else
	{
		while (p->next != NULL)   //循环到尾部的前一个
		{
			ptemp = p;            //将ptemp指向尾部的前一个节点
			p = p->next;          //p指向最后一个节点
		}
		if(connect_again_sign==-1)
		{
			while(1)
			{
				usleep(2000);
				if(connect_again_sign==1)
				{
					break;
				}
			}
		}
		len =send(sockfd,p->tcp_data,sizeof(p->tcp_data),0);
		if (len <= 0)
		{
			perror("send");
			char tmp_log[256];
	        sprintf(tmp_log,"%s%s","send error:",strerror(errno));
	        save_error_log(tmp_log);
		}
		delete p;                //删除尾部节点
		p = NULL;
		ptemp->next = NULL;
	}
}

/************************************************************
*func:		log_in()
*param:	
*descrp:	log in
*author:	Darren
*date:		2019.7.17
*ver:		v1.0.0
*change:
************************************************************/
void TCP_CLIENT::log_in()
{
	unsigned char ary[MAXBUF];
	memcpy(ary,message_head(1),23*sizeof(char));
	ary[23]=0x2a;//数据单元长度
	time_t t;
	struct tm*lt;
	time (&t);//获取Unix时间戳
	lt = localtime(&t);
	ary[24]=lt->tm_year-100;
	ary[25]=lt->tm_mon+1;
	ary[26]=lt->tm_mday;
	ary[27]=lt->tm_hour;
	ary[28]=lt->tm_min;
	ary[29]=lt->tm_sec;//数据采集时间
	ary[30]=0;
	ary[31]=login_num++;//登入流水号
	const char *s3="83605337981605490187";
	memcpy(ary+32,s3,20*sizeof(char));//ICCID
	ary[52]=1;//可充电储能子系统数
	ary[53]=12;//编码长度
	const char *s4="10fff01011ff";
	memcpy(ary+54,s4,12*sizeof(char));
	int s5=ary[0];
	int i;
	for (i = 0; i <65; i++)
	{
		s5^=ary[i+1];
	}
	ary[66]=s5;//校验码
	bzero(buffer, MAXBUF + 1);
	int j;
	for (j=0;j<67;j++)
	{
		buffer[j]=ary[j];
	}
	send_buftosend(buffer);
	log.save_normal_log(ary);
}
/************************************************************
*func:		set_datasend&heartbeat()
*param:	
*descrp:	see datasend and heartbeat
*author:	Darren
*date:		2019.7.17
*ver:		v1.0.0
*change:
************************************************************/
int TCP_CLIENT::set_datasend_heartbeat(void)
{
	struct itimerspec ts;
	int ret;
	ret = dcmi_sol_pthread_attr_init(&attr);
	if (ret != 0) {
		printf("init pthread attributes fail(%d)!\n", ret);
		exit(-1);
	}//初始化线程
	memset(&data_evp, 0, sizeof(struct sigevent));
	data_evp.sigev_value.sival_ptr = &data_timer;
	data_evp.sigev_notify = SIGEV_THREAD;
	data_evp.sigev_notify_function = datasend_timeout;
	data_evp.sigev_notify_attributes = NULL;//设置数据上传线程
	memset(&heartbeat_evp, 0, sizeof(struct sigevent));
	heartbeat_evp.sigev_value.sival_ptr = &heartbeat_timer;
	heartbeat_evp.sigev_notify = SIGEV_THREAD;
	heartbeat_evp.sigev_notify_function = heartbeat_timeout;
	heartbeat_evp.sigev_notify_attributes = NULL; //设置心跳上传线程
	ret = timer_create(CLOCK_REALTIME, &data_evp, &data_timer);
	if(ret != 0) {
		perror("data timer_create fail!");
		exit(-1);
	}//设置数据上传
	ret = timer_create(CLOCK_REALTIME, &heartbeat_evp, &heartbeat_timer);
	if (ret != 0) {
		timer_delete(data_timer);
		perror("heartbeat timer_create fail!");
		exit(-1);
	}//设置心跳上传
	ts.it_interval.tv_sec = 0;
	ts.it_interval.tv_nsec = 0;
	ts.it_value.tv_sec = 1;
	ts.it_value.tv_nsec = 0;
	ret = timer_settime(data_timer, CLOCK_REALTIME, &ts, NULL);
	if(ret != 0) {
		perror("data timer_settime fail!");
		timer_delete(data_timer);
		timer_delete(heartbeat_timer);
		exit(-1);
	}//设置数据上传时间
	ts.it_value.tv_sec = heartbeat_time;
	ret = timer_settime(heartbeat_timer, CLOCK_REALTIME, &ts, NULL);
	if(ret != 0) {
		perror("heartbeat timer settime fail!");
		timer_delete(data_timer);
		timer_delete(heartbeat_timer);
		exit(-1);
	}//设置心跳上传时间
	return 0;
}


/************************************************************
*func:		log_out()
*param:	
*descrp:	log out
*author:	Darren
*date:		2019.7.17
*ver:		v1.0.0
*change:
************************************************************/
void TCP_CLIENT::log_out()
{
	unsigned char ary[MAXBUF];
	memcpy(ary,message_head(4),23*sizeof(char));
	ary[23]=0x08;//数据单元长度
	time_t t;
	struct tm*lt;
	time (&t);//获取Unix时间戳
	lt = localtime(&t);
	ary[24]=lt->tm_year-100;
	ary[25]=lt->tm_mon+1;
	ary[26]=lt->tm_mday;
	ary[27]=lt->tm_hour;
	ary[28]=lt->tm_min;
	ary[29]=lt->tm_sec;//数据采集时间
	ary[30]=0;
	ary[31]=login_num;//登出流水号
	int s5=ary[0];
	int i;
	for (i = 0; i <31; i++)
    {
    	s5^=ary[i+1];
    }
	ary[32]=s5;//校验码
	bzero(buffer, MAXBUF + 1);
	int j;
	for (j=0;j<33;j++)
	{
		buffer[j]=ary[j];//转存到buffer
	}
	send_buftosend(buffer);
	log.save_normal_log(ary);
}

/************************************************************
*func:		time_check()
*param:	
*descrp:	check the time
*author:	Darren
*date:		2019.7.17
*ver:		v1.0.0
*change:
************************************************************/
void TCP_CLIENT::time_check()
{
	unsigned char ary[MAXBUF];
	memcpy(ary,message_head(8),23*sizeof(char));
	ary[23]=0x00;//数据单元长度(为0,无数据单元）
	int s3=ary[0];
	int i;
	for (i = 0; i <23; i++)
    {       
    	s3^=ary[i+1];
    }
	ary[24]=s3;//校验码
	bzero(buffer, MAXBUF + 1);
	int j;
	for (j=0;j<25;j++)
	{
		buffer[j]=ary[j];
	}
	send_buftosend(buffer);
}

/*********************************************
*func:		BCC_check()
*param:		buf_packet[]
*return		bool:ture or false
*descrp:	数据异或校验
*author:	Darren
*date:		2019.7.18
*ver:		v1.0.0
*change:	
**********************************************/
bool TCP_CLIENT::BCC_check(unsigned char buffera[])
{
	int buf_length=((buffera[22+buf_bit]<<8)+buffera[23+buf_bit]+25);
	int i;
	int BCC_code=buffera[buf_bit];
	for (i = buf_bit; i < buf_bit+buf_length-2; i++)
    {
   		BCC_code^=buffera[buf_bit+i+1];
   	}
	if (BCC_code == buf_packet[buf_bit+buf_length-1])
	{
		return(true);
	}
	else
	{
		return(false);
	}
}

/*********************************************
*func:		dcmi_sol_pthread_attr_destroy()
*param:		pthread_attr_t *attr
*descrp:	摧毁线程
*author:	Darren
*date:		2019.7.20
*ver:		v1.0.0
*change:	
**********************************************/
static void dcmi_sol_pthread_attr_destroy(pthread_attr_t *attr)
{
	pthread_attr_destroy(attr);
}

/*********************************************
*func:		dcmi_sol_pthread_attr_init()
*param:		pthread_attr_t *attr
*descrp:	初始化线程
*author:	Darren
*date:		2019.7.20
*ver:		v1.0.0
*change:	
**********************************************/
static int dcmi_sol_pthread_attr_init(pthread_attr_t *attr)
{
	int ret;
	if ((ret = pthread_attr_init(attr) != 0)) {
		goto err;
	}
	if ((ret = pthread_attr_setdetachstate(attr, PTHREAD_CREATE_DETACHED)) != 0) {
		dcmi_sol_pthread_attr_destroy(attr);
		goto err;
	}
	/* 设置线程的栈大小,失败则用系统默认值 */
	pthread_attr_setstacksize(attr, 128 * 1024);
	return 0;
	err:
	printf("set ptread attr failed(ret:%d)!\n", ret);
	return -1;
}

/*********************************************
*func:		respond_login()
*param:		buf_packet[]
*descrp:	respond after sending login messages 
*author:	Darren
*date:		2019.7.18
*ver:		v1.0.0
*change:	
**********************************************/
void TCP_CLIENT::respond_login(unsigned char buf_packet[])
{
	int respond_sign=buf_packet[3];
	switch(respond_sign)	
	{
		case 0x01:	
			printf("车辆登入成功！\n");
			set_datasend_heartbeat();
			loop2=1;
			connect_again_sign = 0;
			printf("%ds定期发送实时信息,默认时间间隔为7s\n",datasend_time);
			printf("%ds定期发送心跳,默认时间间隔为30s\n",heartbeat_time);
			break;
		case 0x02:	printf("车辆登入失败！\n");break;
		case 0x03:	printf("发送数据重复！\n");break;
		case 0xfe:	printf("所接收数据为命令指示！\n");break;
		default:	printf("数据错误！\n");
	}
}

/************************************************************
*func:		heartbeat_send()
*param:	
*descrp:	send heartbeat message
*author:	Darren
*date:		2019.7.17
*ver:		v1.0.0
*change:
************************************************************/
void TCP_CLIENT::heartbeat_send()
{
	unsigned char heart[MAXBUF];
	unsigned char buffer3[MAXBUF+1];
	memcpy(heart,message_head(7),23*sizeof(char));
	heart[23]=0x00;//数据单元长度(为0,无数据单元）
	int s3=heart[0];
	int i;
	for (i = 0; i <23; i++)
	{       
		s3^=heart[i+1];
	}
	heart[24]=s3;//校验码
	bzero(buffer3, MAXBUF + 1);
	int j;
	for (j=0;j<25;j++)
	{
		buffer3[j]=heart[j];
	}
	send_buftosend(buffer3);
}

/************************************************************
*func:		modify_heartbeat_time()
*param:	
*descrp:	send the message of modifying heartbeat time
*author:	Darren
*date:		2019.7.22
*ver:		v1.0.0
*change:
************************************************************/
void TCP_CLIENT::modify_heartbeat_time()
{
	unsigned char heart[MAXBUF];
	unsigned char buffer3[MAXBUF+1];
	memcpy(heart,message_head(9),23*sizeof(char));
	heart[23]=0x01;//数据单元长度
	heart[24]=heartbeat_time;
	int s3=heart[0];
	int i;
	for (i = 0; i <24; i++)
	{       
		s3^=heart[i+1];
	}
	heart[25]=s3;//校验码
	bzero(buffer3, MAXBUF + 1);
	int j;
	for (j=0;j<26;j++)
	{
		buffer3[j]=heart[j];
	}
	send_buftosend(buffer3);
}



/*********************************************
*func:		message_head()
*param:		sendorder_sign
*descrp:	the head of sending messages 
*author:	Darren
*date:		2019.7.22
*ver:		v1.0.0
*change:	
**********************************************/
unsigned char *TCP_CLIENT::message_head(int sendorder_sign)
{
	const char *s1="##";//开头
	memcpy(data_head, s1, 2*sizeof(char));
	data_head[2]=sendorder_sign;//命令标识
	data_head[3]=0xFE;//应答标志
	const char *s2="LFV2A2156C3333333";
	memcpy(data_head+4,s2,17*sizeof(char));//唯一识别码
	data_head[21]=0x01;//数据加密方式
	data_head[22]=0x00;
	return data_head;
}

/*********************************************
*func:		respond_logout()
*param:		buf_packet[]
*descrp:	respond after sending logout messages 
*author:	Darren
*date:		2019.7.18
*ver:		v1.0.0
*change:	
**********************************************/
void TCP_CLIENT::respond_logout(unsigned char bufferb[])
{
	int respond_sign=bufferb[3];
	switch(respond_sign)	
	{
		case 0x01:	
			printf("车辆登出成功！\n");
			timer_delete(data_timer);
			timer_delete(heartbeat_timer);
			break;
		case 0x02:	printf("车辆登出失败！\n");break;
		case 0x03:	printf("发送数据重复！\n");break;
		case 0xfe:	printf("所接收数据为命令指示！\n");break;
		default:	printf("数据错误！\n");
	}
}

/*********************************************
*func:		respond_data()
*param:		buf_packet[]
*descrp:	respond after sending data
*author:	Darren
*date:		2019.7.19
*ver:		v1.0.0
*change:
**********************************************/
void TCP_CLIENT::respond_data(unsigned char bufferb[])
{
	int respond_sign=bufferb[3];
	switch(respond_sign)	
	{
		case 0x01:	
			printf("实时数据上报成功！\n");
			tcp_check=0;
			break;
		case 0x02:	printf("实时数据上报失败！\n");break;
		case 0x03:	printf("发送数据重复！\n");break;
		case 0xfe:	printf("所接收数据为命令指示！\n");break;
		default:	printf("数据错误！\n");
	}
}

/*********************************************
*func:		respond_reissue()
*param:		buf_packet[]
*descrp:	respond after reissue data
*author:	Darren
*date:		2019.7.19
*ver:		v1.0.0
*change:
**********************************************/
void TCP_CLIENT::respond_reissue(unsigned char bufferb[])
{
	int respond_sign=bufferb[3];
	switch(respond_sign)
	{
		case 0x01:
			printf("补发数据上报成功！\n");
			tcp_check=0;
			break;
		case 0x02:	printf("补发数据上报失败！\n");break;
		case 0x03:	printf("发送数据重复！\n");break;
		case 0xfe:	printf("所接收数据为命令指示！\n");break;
		default:	printf("数据错误！\n");
	}
}

/*********************************************
*func:		respond_time()
*param:		buf_packet[]
*descrp:	respond after sending time check messages and correct the time
*author:	Darren
*date:		2019.7.18
*ver:		v1.0.0
*change:	
**********************************************/
void TCP_CLIENT::respond_time(unsigned char bufferb[])
{
	int respond_sign=bufferb[3];
	switch(respond_sign)
	{
		case 0x01:	
			printf("时间校对中！\n");
			struct tm _tm;
			struct timeval tv;
			time_t timep;
			_tm.tm_year = bufferb[24]+100;
			_tm.tm_mon = bufferb[25] - 1; 
			_tm.tm_mday = bufferb[26];
			_tm.tm_hour = bufferb[27];
			_tm.tm_min = bufferb[28];
			_tm.tm_sec = bufferb[29];
			timep = mktime(&_tm);
			tv.tv_sec = timep;
			tv.tv_usec = 0;
			if(settimeofday (&tv, (struct timezone *) 0) < 0)
			{
				printf("Set system datatime error!\n");
				break;
			}
			time_t timer;
			struct tm t_tm;
			time(&timer);
			localtime_r(&timer, &t_tm);
			printf("校时成功，today is %4d/%02d/%02d %02d:%02d:%02d\r\n", t_tm.tm_year+1900,t_tm.tm_mon+1, t_tm.tm_mday, t_tm.tm_hour, t_tm.tm_min, t_tm.tm_sec);
			break;
		case 0x02:	printf("时间校对失败！\n");break;
		case 0x03:	printf("发送数据重复！\n");break;
		case 0xfe:	printf("所接收数据为命令指示！\n");break;
		default:	printf("数据错误！\n");
	}
}

/*********************************************
*func:		respond_heartbeat()
*param:		buf_packet[]
*descrp:	respond after sending heartbeat messages 
*author:	Darren
*date:		2019.7.18
*ver:		v1.0.0
*change:	
**********************************************/
void TCP_CLIENT::respond_heartbeat(unsigned char bufferb[])
{
	int respond_sign=bufferb[3];
	switch(respond_sign)	
	{
		case 0x01:	
			tcp_check=0;
			break;
		case 0x02:	printf("车辆登入失败！\n");break;
		case 0x03:	printf("发送数据重复！\n");break;
		case 0xfe:	printf("所接收数据为命令指示！\n");break;
		default:	printf("数据错误！\n");
	}
}

/*********************************************
*func:		respond_modify_heartbeat()
*param:		buf_packet[]
*descrp:	respond after sending heartbeat modifying messages 
*author:	Darren
*date:		2019.7.22
*ver:		v1.0.0
*change:	
**********************************************/
void TCP_CLIENT::respond_modify_heartbeat(unsigned char bufferb[])
{
	int respond_sign=bufferb[3];
	switch(respond_sign)	
	{
		case 0x01:	
			printf("心跳时间修改成功！\n");
			tcp_check=0;
			break;
		case 0x02:	printf("心跳时间修改失败！\n");break;
		case 0x03:	printf("发送数据重复！\n");break;
		case 0xfe:	printf("所接收数据为命令指示！\n");break;
		default:	printf("数据错误！\n");
	}
}

/*********************************************
*func:		respond_inquire()
*param:		buf_packet[]
*descrp:	respond after receiving inquiry messages 
*author:	Darren
*date:		2019.7.22
*ver:		v1.0.0
*change:	
**********************************************/
void TCP_CLIENT::respond_inquire(unsigned char bufferb[])
{
	int respond_sign=bufferb[3];
	switch(respond_sign)	
	{
		case 0xfe:	
			send_inquire(bufferb);
			printf("查阅参数发送成功！\n");
			break;
		case 0x02:	printf("心跳时间修改失败！\n");break;
		case 0x03:	printf("发送数据重复！\n");break;
		case 0x01:	printf("所接收数据为应答指示！\n");break;
		default:	printf("数据错误！\n");
	}
}

/*********************************************
*func:		respond_set_parameter()
*param:		buf_packet[]
*descrp:	respond after receiving parameter setting messages 
*author:	Darren
*date:		2019.7.23
*ver:		v1.0.0
*change:	
**********************************************/
void TCP_CLIENT::respond_set_parameter(unsigned char bufferb[])
{
	int respond_sign=bufferb[3];
	switch(respond_sign)	
	{
		case 0xfe:
			set_parameter(bufferb);
			printf("设置参数完成！\n");
			break;
		case 0x02:	printf("心跳时间修改失败！\n");break;
		case 0x03:	printf("发送数据重复！\n");break;
		case 0x01:	printf("所接收数据为应答指示！\n");break;
		default:	printf("数据错误！\n");
	}
}

/*********************************************
*func:		send_inquire()
*param:		buf_packet[]
*descrp:	send messages after receiving inquiry messages 
*author:	Darren
*date:		2019.7.22
*ver:		v1.0.0
*change:	
**********************************************/
void TCP_CLIENT::send_inquire(unsigned char buf_packet[])
{
	unsigned char inquire[MAXBUF];
	unsigned char buffer3[MAXBUF+1];
	int inq_num=buf_packet[30];
	memcpy(inquire,buf_packet,24*sizeof(char));
	inquire[3]=0x01;
	int n=24;
	time_t t;
	struct tm*lt;
	time (&t);//获取Unix时间戳
	lt = localtime(&t);
	inquire[n++]=lt->tm_year-100;
	inquire[n++]=lt->tm_mon+1;
	inquire[n++]=lt->tm_mday;
	inquire[n++]=lt->tm_hour;
	inquire[n++]=lt->tm_min;
	inquire[n++]=lt->tm_sec;//数据采集时间
	inquire[n++]=inq_num;
	int i,g;
	for (i=0;i<inq_num;i++){
		switch (buf_packet[31+i])
		{
			case 1:
				inquire[n++]=1;
				inquire[n++]=car_parameter.time_period>>8;
				inquire[n++]=car_parameter.time_period&0xff;
				break;
			case 2:
				inquire[n++]=2;
				inquire[n++]=car_parameter.normal_time_period>>8;
				inquire[n++]=car_parameter.normal_time_period&0xff;
				break;
			case 3:
				inquire[n++]=3;
				inquire[n++]=car_parameter.alarm_time_period>>8;
				inquire[n++]=car_parameter.alarm_time_period&0xff;
				break;
			case 4:
				inquire[n++]=4;
				inquire[n++]=car_parameter.domain_name_length;
				break;
			case 5:
				inquire[n++]=5;
				for(g=0;g<car_parameter.domain_name_length;g++){
					inquire[n++]=car_parameter.domain_name[g];
				}
				break;
			case 6:
				inquire[n++]=6;
				inquire[n++]=car_parameter.tcp_port>>8;
				inquire[n++]=car_parameter.tcp_port&0xff;
				break;
			case 7:
				inquire[n++]=7;
				memcpy(inquire+n,car_parameter.hardware_version,5*sizeof(char));
				n+=5;
				break;
			case 8:
				inquire[n++]=8;
				memcpy(inquire+n,car_parameter.firmware_version,5*sizeof(char));
				n+=5;
				break;
			case 9:
				inquire[n++]=9;
				inquire[n++]=car_parameter.heartbeat_send_period;
				break;
			case 0x0a:
				inquire[n++]=0x0a;
				inquire[n++]=car_parameter.respond_overtime_time>>8;
				inquire[n++]=car_parameter.respond_overtime_time&0xff;
				break;
			case 0x0b:
				inquire[n++]=0x0b;
				inquire[n++]=car_parameter.platform_overtime_time>>8;
				inquire[n++]=car_parameter.platform_overtime_time&0xff;
				break;
			case 0x0c:
				inquire[n++]=0x0c;
				inquire[n++]=car_parameter.gap_login_time;
				break;
			case 0x0d:
				inquire[n++]=0x0d;
				inquire[n++]=car_parameter.common_domain_name_length;
				break;
			case 0x0e:
				inquire[n++]=0x0e;
				for(g=0;g<car_parameter.common_domain_name_length;g++){
					inquire[n++]=car_parameter.common_domain_name[g];
				}
				break;
			case 0x0f:
				inquire[n++]=0x0f;
				inquire[n++]=car_parameter.common_tcp_port>>8;
				inquire[n++]=car_parameter.common_tcp_port&0xff;
				break;
			case 0x10:
				inquire[n++]=0x10;
				inquire[n++]=car_parameter.sampling_inspection;
				break;
		}
	}
	inquire[23]=n-24;
	int s3=inquire[0];
	int b;
	for (b = 1; b <n; b++)
	{       
		s3^=inquire[b];
	}
	inquire[n]=s3;//校验码
	bzero(buffer3, MAXBUF + 1);
	int j;
	for (j=0;j<n+1;j++)
	{
		buffer3[j]=inquire[j];
	}
	send_buftosend(buffer3);
}
/*********************************************
*func:		set_parameter()
*param:		buf_packet[]
*descrp:	set parameter  
*author:	Darren
*date:		2019.7.23
*ver:		v1.0.0
*change:	
**********************************************/
void TCP_CLIENT::set_parameter(unsigned char bufferb[])
{
	unsigned char buffer3[MAXBUF+1];
	int i,g;
	int set_num=bufferb[30];
	int n=31;
	for (i=0;i<set_num;i++){
		switch (bufferb[n++])
			{
				case 1:
					car_parameter.time_period=(bufferb[n]<<8+bufferb[n+1]);
					n+=2;
					printf("time_period set done!\n");
					break;
				case 2:
					car_parameter.normal_time_period=(bufferb[n]<<8+bufferb[n+1]);
					n+=2;
					printf("normal time period set done!\n");
					break;
				case 3:
					car_parameter.alarm_time_period=(bufferb[n]<<8+bufferb[n+1]);
					n+=2;
					printf("alarm time period set done!\n");
					break;
				case 4:
					car_parameter.domain_name_length=bufferb[n++];
					printf("domain name length set done!It is %d\n",car_parameter.domain_name_length);
					break;
				case 5:
					bzero(car_parameter.domain_name, 255);
					for(g=0;g<car_parameter.domain_name_length;g++){
					car_parameter.domain_name[g]=bufferb[n++];
					}
					printf("domain name set done!\nIt is ");
					for(g=0;g<car_parameter.domain_name_length;g++){
					printf("%c",car_parameter.domain_name[g]);
					}
					printf("\n");
					break;
				case 6:
					car_parameter.tcp_port=(bufferb[n]<<8+bufferb[n+1]);
					n+=2;
					printf("tcp port set done!\n");
					break;
				case 7:
					bzero(car_parameter.hardware_version,5*sizeof(char));
					memcpy(car_parameter.hardware_version,bufferb+n,5*sizeof(char));
					n+=5;
					printf("hardware version set done!It is %s\n",car_parameter.hardware_version);
					break;
				case 8:
					bzero(car_parameter.firmware_version,5);
					memcpy(car_parameter.firmware_version,bufferb+n,5*sizeof(char));
					n+=5;
					printf("firmware version set done!It is %s\n",car_parameter.firmware_version);
					break;
				case 9:
					car_parameter.heartbeat_send_period=bufferb[n++];
					printf("heartbeat_send_period set done!\n");
					break;
				case 0x0a:
					car_parameter.respond_overtime_time=(bufferb[n]<<8+bufferb[n+1]);
					n+=2;
					printf("respond overtime time set done!\n");
					break;
				case 0x0b:
					car_parameter.platform_overtime_time=(bufferb[n]<<8+bufferb[n+1]);
					n+=2;
					printf("platform overtime time set done!\n");
					break;
				case 0x0c:
					car_parameter.gap_login_time=bufferb[n++];
					printf("gap login time set done!\n");
					break;
				case 0x0d:
					car_parameter.common_domain_name_length=bufferb[n++];
					printf("common domain name length set done!\n");
					break;
				case 0x0e:
					bzero(car_parameter.common_domain_name, 255);
					for(g=0;g<car_parameter.common_domain_name_length;g++){
					car_parameter.common_domain_name[g]=bufferb[n++];
					}
					printf("common domain name set done!\n");
					break;
				case 0x0f:
					car_parameter.common_tcp_port=(bufferb[n]<<8+bufferb[n+1]);
					n+=2;
					printf("common tcp port set done!\n");
					break;
				case 0x10:
					car_parameter.sampling_inspection=bufferb[n++];
					printf("sampling inspection set done!\n");
					break;
			}
		write_parameter();
	}
	bzero(buffer3, MAXBUF + 1);
	int j,s;
	for (j=0;j<n;j++)
	{
		buffer3[j]=bufferb[j];
	}
	int b;
	buffer3[3]=0x01;
	s=buffer3[0];
	for (b = 1; b <n; b++)
	{       
		s^=buffer3[b];
	}
	buffer3[n]=s;//校验码
	send_buftosend(buffer3);
}
/************************************************************
*func:		write_parameter()
*param:	
*descrp:	存储车辆参数至文件中
*author:	Darren
*date:		2019.7.25
*ver:		v1.0.0
*change:
************************************************************/
void TCP_CLIENT::write_parameter()
{
	FILE *fp ;
	fp=fopen("car_data" , "wb" );
	if ( fp == NULL )
	{
		printf("打开存储文件失败!");	
	}
	fwrite( (char*)(&car_parameter) , sizeof(parameter), 1 , fp ); //将数组写入文件
	fclose(fp);
}
/************************************************************
*func:		data_create()
*param:	
*return:	unsigned char []
*descrp:	create data
*author:	Darren
*date:		2019.7.26
*ver:		v1.0.0
*change:
************************************************************/
unsigned char * TCP_CLIENT::data_create()
{
	bzero(ary2,MAXBUF+1);
	memcpy(ary2,message_head(2),23*sizeof(char));
	time_t t;
	struct tm*lt;
	time (&t);//获取Unix时间戳
	lt = localtime(&t);
	ary2[24]=lt->tm_year-100;
	ary2[25]=lt->tm_mon+1;
	ary2[26]=lt->tm_mday;
	ary2[27]=lt->tm_hour;
	ary2[28]=lt->tm_min;
	ary2[29]=lt->tm_sec;//数据采集时间
	int n=30;
	srand((unsigned int)time(NULL)); 
	int m=7;
	int count=0;
	int low_tznum,high_tznum,low_tz,high_tz;
	unsigned char wdtz[MAXBUF];
	switch (1)
	{
		case 1:
			ary2[n++]=0x01;//整车
			ary2[n++]=rand()%2+1;//车辆状态
			ary2[n++]=rand()%2+1;//充电状态
			ary2[n++]=rand()%2+1;//运行模式
			ary2[n++]=rand()%8;
			ary2[n++]=rand()%255;//车速
			ary2[n++]=0;
			ary2[n++]=rand()%255;
			ary2[n++]=rand()%255;
			ary2[n++]=rand()%255;//里程
			ary2[n++]=rand()%26;
			ary2[n++]=rand()%255;//总电压
			ary2[n++]=rand()%26;
			ary2[n++]=rand()%255;//总电流
			ary2[n++]=rand()%100;//soc
			ary2[n++]=rand()%1+1;//DC-DC状态
			ary2[n++]=rand()%15;//档位
			ary2[n++]=rand()%233;
			ary2[n++]=rand()%255;
			ary2[n++]=0;
			ary2[n++]=0;
			count++;
			if (count==m)
			{
				break;
			}
		case 2:
			ary2[n++]=0x02;//驱动电机数据
			ary2[n++]=1;//驱动电机个数
			ary2[n++]=1;//序号
			ary2[n++]=rand()%3+1;//状态
			ary2[n++]=rand()%250;//控制器温度
			ary2[n++]=rand()%254;
			ary2[n++]=rand()%255;//转速
			ary2[n++]=rand()%254;
			ary2[n++]=rand()%255;//转矩
			ary2[n++]=rand()%250;//温度
			ary2[n++]=rand()%233;
			ary2[n++]=rand()%255;//输入电压
			ary2[n++]=rand()%77;
			ary2[n++]=rand()%255;//母线电流
			count++;
			if (count==m)
			{
				break;
			}
		case 3:
		{	ary2[n++]=0x03;//燃料电池标识
			ary2[n++]=rand()%70;
			ary2[n++]=rand()%255;//燃料电池电压
			ary2[n++]=rand()%70;
			ary2[n++]=rand()%250;//燃料电池电流
			ary2[n++]=rand()%230;
			ary2[n++]=rand()%255;//燃料消耗率
			ary2[n++]=0;
			ary2[n++]=rand()%24+1;//温度探针总数
			int tz;
			tz=ary2[n-1];
			int wd;
			for (wd=0;wd<tz;wd++){
			ary2[n++]=rand()%240;
			wdtz[wd]=ary2[n-1];
			}
			int temp;
			int c=0;
			for(c=0;c<tz-1;c++)
			{
				if(wdtz[c]>wdtz[c+1])
				{			
				temp=wdtz[c];
				wdtz[c]=wdtz[c+1];
				wdtz[c+1]=temp;
				}
			}
			high_tz=wdtz[tz-1];
			for(c=0;c<tz-1;c++)
			{
				if(wdtz[c]<wdtz[c+1])
				{			
				temp=wdtz[c];
				wdtz[c]=wdtz[c+1];
				wdtz[c+1]=temp;
				}
			}
			low_tz=wdtz[tz-1];
			for(c=n-tz;c<n;c++){
				if (ary2[c]==high_tz){
					high_tznum=c-74;
				}
				if (ary2[c]==low_tz){
					low_tznum=c-74;
				}
			}
			ary2[n++]=((10*high_tz)>>8);
			ary2[n++]=(10*high_tz&0xff);//氢系统中最高温度
			ary2[n++]=high_tznum;//氢系统中最高温度探针代号
			ary2[n++]=rand()%233;
			ary2[n++]=rand()%255;//氢气最高浓度
			ary2[n++]=rand()%251+1;//氢气最高浓度代号
			ary2[n++]=rand()%61;
			ary2[n++]=rand()%255;//氢气最高压力
			ary2[n++]=rand()%251+1;//氢气最高压力传感器代号
			ary2[n++]=rand()%1+1;//高压DC/DC状态
			count++;
			if (count==m)
			{
				break;
			}
		}	
		case 4:
			ary2[n++]=0x04;//发动机数据标识
			ary2[n++]=0x01;//发动机状态
			ary2[n++]=rand()%233;
			ary2[n++]=rand()%255;//曲轴转速
			ary2[n++]=rand()%233;
			ary2[n++]=rand()%255;//燃料消耗率
			count++;
			if (count==m)
			{
				break;
			}
		case 5:
			ary2[n++]=0x05;//车辆位置标识
			ary2[n++]=0x07;//状态位
			ary2[n++]==rand()%9;
			ary2[n++]=rand()%255;
			ary2[n++]=rand()%255;
			ary2[n++]=rand()%255;//经度
			ary2[n++]==rand()%9;
			ary2[n++]=rand()%255;
			ary2[n++]=rand()%255;
			ary2[n++]=rand()%255;//纬度
			count++;
			if (count==m)
			{
				break;
			}
		case 6:
			ary2[n++]=0x06;//极值数据
			ary2[n++]==rand()%249+1;//最高电压子系统号
			ary2[n++]=rand()%249+1;//最高电压电池单体代号
			ary2[n++]=rand()%57;
			ary2[n++]=rand()%255;//电池单体电压最高值
			ary2[n++]==rand()%249+1;//最低电压子系统号
			ary2[n++]=rand()%249+1;//最低电压电池单体代号
			ary2[n++]=rand()%57;
			ary2[n++]=rand()%255;//电池单体电压最低值
			ary2[n++]==rand()%249+1;//最高温度系统号
			ary2[n++]=high_tznum;//最高温度探针号
			ary2[n++]=high_tz;//最高温度
			ary2[n++]==rand()%249+1;//最低温度系统号
			ary2[n++]=low_tznum;//最低温度探针号
			ary2[n++]=low_tz;//最低温度
			count++;
			if (count==m)
			{
				break;
			}
		case 7:
			ary2[n++]=0x07;//报警数据
			ary2[n++]==rand()%3;//最高报警等级
			ary2[n++]=0;
			ary2[n++]=rand()%3;
			ary2[n++]=rand()%255;
			ary2[n++]=rand()%255;//通用报警标志
			ary2[n++]=1;//可充电储能装置故障总数
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;//可充电储能装置故障代码列表
			ary2[n++]=1;//驱动电机故障总数
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;//驱动电机故障代码列表
			ary2[n++]=1;//发动机故障总数
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;//发动机故障代码列表
			ary2[n++]=1;//其他故障总数
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;//其它故障代码列表
			count++;
			if (count==m)
			{
				break;
			}
			break;
	}
	ary2[23]=n-24;//数据单元长度
	int s5=ary2[0];
	int i;
	for (i = 0; i <n-1; i++)
    	{
    		s5^=ary2[i+1];
    	}
	ary2[n]=s5;//校验码
	return ary2;
}

/************************************************************
*func:		send_data()
*param:		unsigned char []
*descrp:	发送实时数据
*author:	Darren
*date:		2019.7.19
*ver:		v1.0.0
*change:
************************************************************/
void TCP_CLIENT::send_data(unsigned char [])
{
	bzero(buffer, MAXBUF + 1);
	int j;
	for (j=0;j<MAXBUF;j++)
	{
		buffer[j]=data_create()[j];//转存到buffer
	}
	send_buftosend(buffer);
}

/************************************************************
*func:		close_socket()
*param:	
*descrp:	close sockets
*author:	Darren
*date:		2019.7.11
*ver:		v1.0.0
*change:
************************************************************/
int TCP_CLIENT::close_socket()
{
    close(sockfd);
	timer_delete(data_timer);
	timer_delete(heartbeat_timer);
    printf("tcp quit done \n");
}
