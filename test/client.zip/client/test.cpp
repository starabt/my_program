#include "tcp_client.h"
extern int sockfd;
extern unsigned char buffer2[MAXBUF + 1];
extern unsigned char data_head[MAXBUF+1];
extern unsigned char ary2[MAXBUF+1];

/************************************************************
*func:		test1()
*param:	
*descrp:	close sockets
*author:	Darren
*date:		2019.7.11
*ver:		v1.0.0
*change:
************************************************************/
void test1()
{
	bzero(ary2,1025);
	ary2[0]=0x23;
	ary2[1]=0x23;
	memcpy(ary2+2,tcp_client.message_head(2),23*sizeof(char));
	time_t t;
	struct tm*lt;
	time (&t);//获取Unix时间戳
	lt = localtime(&t);
	ary2[26]=lt->tm_year-100;
	ary2[27]=lt->tm_mon+1;
	ary2[28]=lt->tm_mday;
	ary2[29]=lt->tm_hour;
	ary2[30]=lt->tm_min;
	ary2[31]=lt->tm_sec;//数据采集时间
	int n=32;
	srand((unsigned int)time(NULL)); 
	int m=7;
	int count=0;
	int low_tznum,high_tznum,low_tz,high_tz;
	unsigned char wdtz[MAXBUF];
	switch (1)
	{
		case 1:
			ary2[n++]=0x01;//整车
			ary2[n++]=rand()%2+1;//车辆状态
			ary2[n++]=rand()%2+1;//充电状态
			ary2[n++]=rand()%2+1;//运行模式
			ary2[n++]=rand()%8;
			ary2[n++]=rand()%255;//车速
			ary2[n++]=0;
			ary2[n++]=rand()%255;
			ary2[n++]=rand()%255;
			ary2[n++]=0x23;//里程
			ary2[n++]=0x23;
			ary2[n++]=0x23;//总电压
			ary2[n++]=rand()%26;
			ary2[n++]=rand()%255;//总电流
			ary2[n++]=rand()%100;//soc
			ary2[n++]=rand()%1+1;//DC-DC状态
			ary2[n++]=rand()%15;//档位
			ary2[n++]=rand()%233;
			ary2[n++]=rand()%255;
			ary2[n++]=0;
			ary2[n++]=0;
			count++;
			if (count==m)
			{
				break;
			}
		case 2:
			ary2[n++]=0x02;//驱动电机数据
			ary2[n++]=1;//驱动电机个数
			ary2[n++]=1;//序号
			ary2[n++]=rand()%3+1;//状态
			ary2[n++]=rand()%250;//控制器温度
			ary2[n++]=rand()%254;
			ary2[n++]=0x23;//转速
			ary2[n++]=0x23;
			ary2[n++]=0x23;//转矩
			ary2[n++]=rand()%250;//温度
			ary2[n++]=rand()%233;
			ary2[n++]=rand()%255;//输入电压
			ary2[n++]=rand()%77;
			ary2[n++]=rand()%255;//母线电流
			count++;
			if (count==m)
			{
				break;
			}
		case 3:
		{	ary2[n++]=0x03;//燃料电池标识
			ary2[n++]=rand()%70;
			ary2[n++]=rand()%255;//燃料电池电压
			ary2[n++]=rand()%70;
			ary2[n++]=rand()%250;//燃料电池电流
			ary2[n++]=rand()%230;
			ary2[n++]=rand()%255;//燃料消耗率
			ary2[n++]=0;
			ary2[n++]=rand()%24+1;//温度探针总数
			int tz;
			tz=ary2[n-1];
			int wd;
			for (wd=0;wd<tz;wd++){
			ary2[n++]=rand()%240;
			wdtz[wd]=ary2[n-1];
			}
			int temp;
			int c=0;
			for(c=0;c<tz-1;c++)
			{
				if(wdtz[c]>wdtz[c+1])
				{			
				temp=wdtz[c];
				wdtz[c]=wdtz[c+1];
				wdtz[c+1]=temp;
				}
			}
			high_tz=wdtz[tz-1];
			for(c=0;c<tz-1;c++)
			{
				if(wdtz[c]<wdtz[c+1])
				{			
				temp=wdtz[c];
				wdtz[c]=wdtz[c+1];
				wdtz[c+1]=temp;
				}
			}
			low_tz=wdtz[tz-1];
			for(c=n-tz;c<n;c++){
				if (ary2[c]==high_tz){
					high_tznum=c-74;
				}
				if (ary2[c]==low_tz){
					low_tznum=c-74;
				}
			}
			ary2[n++]=((10*high_tz)>>8);
			ary2[n++]=(10*high_tz&0xff);//氢系统中最高温度
			ary2[n++]=high_tznum;//氢系统中最高温度探针代号
			ary2[n++]=rand()%233;
			ary2[n++]=rand()%255;//氢气最高浓度
			ary2[n++]=rand()%251+1;//氢气最高浓度代号
			ary2[n++]=rand()%61;
			ary2[n++]=rand()%255;//氢气最高压力
			ary2[n++]=rand()%251+1;//氢气最高压力传感器代号
			ary2[n++]=rand()%1+1;//高压DC/DC状态
			count++;
			if (count==m)
			{
				break;
			}
		}	
		case 4:
			ary2[n++]=0x04;//发动机数据标识
			ary2[n++]=0x01;//发动机状态
			ary2[n++]=rand()%233;
			ary2[n++]=rand()%255;//曲轴转速
			ary2[n++]=rand()%233;
			ary2[n++]=rand()%255;//燃料消耗率
			count++;
			if (count==m)
			{
				break;
			}
		case 5:
			ary2[n++]=0x05;//车辆位置标识
			ary2[n++]=0x07;//状态位
			ary2[n++]==rand()%9;
			ary2[n++]=rand()%255;
			ary2[n++]=rand()%255;
			ary2[n++]=rand()%255;//经度
			ary2[n++]==rand()%9;
			ary2[n++]=rand()%255;
			ary2[n++]=rand()%255;
			ary2[n++]=rand()%255;//纬度
			count++;
			if (count==m)
			{
				break;
			}
		case 6:
			ary2[n++]=0x06;//极值数据
			ary2[n++]==rand()%249+1;//最高电压子系统号
			ary2[n++]=rand()%249+1;//最高电压电池单体代号
			ary2[n++]=rand()%57;
			ary2[n++]=rand()%255;//电池单体电压最高值
			ary2[n++]==rand()%249+1;//最低电压子系统号
			ary2[n++]=rand()%249+1;//最低电压电池单体代号
			ary2[n++]=rand()%57;
			ary2[n++]=rand()%255;//电池单体电压最低值
			ary2[n++]==rand()%249+1;//最高温度系统号
			ary2[n++]=high_tznum;//最高温度探针号
			ary2[n++]=high_tz;//最高温度
			ary2[n++]==rand()%249+1;//最低温度系统号
			ary2[n++]=low_tznum;//最低温度探针号
			ary2[n++]=low_tz;//最低温度
			count++;
			if (count==m)
			{
				break;
			}
		case 7:
			ary2[n++]=0x07;//报警数据
			ary2[n++]==rand()%3;//最高报警等级
			ary2[n++]=0;
			ary2[n++]=rand()%3;
			ary2[n++]=rand()%255;
			ary2[n++]=rand()%255;//通用报警标志
			ary2[n++]=1;//可充电储能装置故障总数
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;//可充电储能装置故障代码列表
			ary2[n++]=1;//驱动电机故障总数
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;//驱动电机故障代码列表
			ary2[n++]=1;//发动机故障总数
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;//发动机故障代码列表
			ary2[n++]=1;//其他故障总数
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;//其它故障代码列表
			count++;
			if (count==m)
			{
				break;
			}
			break;
	}
	ary2[27]=n-24;//数据单元长度
	int s5=ary2[2];
	int i;
	for (i = 2; i <n-1; i++)
    	{
    		s5^=ary2[i+1];
    	}
	ary2[n]=s5;//校验码
	send(sockfd,ary2,MAXBUF+1,0);
}

/************************************************************
*func:		test2()
*param:	
*descrp:	close sockets
*author:	Darren
*date:		2019.7.11
*ver:		v1.0.0
*change:
************************************************************/
void test2()
{
	bzero(ary2,1025);
	memcpy(ary2,tcp_client.message_head(2),23*sizeof(char));
	time_t t;
	struct tm*lt;
	time (&t);//获取Unix时间戳
	lt = localtime(&t);
	ary2[24]=lt->tm_year-100;
	ary2[25]=lt->tm_mon+1;
	ary2[26]=lt->tm_mday;
	ary2[27]=lt->tm_hour;
	ary2[28]=lt->tm_min;
	ary2[29]=lt->tm_sec;//数据采集时间
	int n=30;
	srand((unsigned int)time(NULL)); 
	int m=7;
	int count=0;
	int low_tznum,high_tznum,low_tz,high_tz;
	unsigned char wdtz[MAXBUF];
	switch (1)
	{
		case 1:
			ary2[n++]=0x01;//整车
			ary2[n++]=rand()%2+1;//车辆状态
			ary2[n++]=rand()%2+1;//充电状态
			ary2[n++]=rand()%2+1;//运行模式
			ary2[n++]=rand()%8;
			ary2[n++]=rand()%255;//车速
			ary2[n++]=0;
			ary2[n++]=rand()%255;
			ary2[n++]=rand()%255;
			ary2[n++]=rand()%255;//里程
			ary2[n++]=rand()%26;
			ary2[n++]=rand()%255;//总电压
			ary2[n++]=rand()%26;
			ary2[n++]=rand()%255;//总电流
			ary2[n++]=rand()%100;//soc
			ary2[n++]=rand()%1+1;//DC-DC状态
			ary2[n++]=rand()%15;//档位
			ary2[n++]=rand()%233;
			ary2[n++]=rand()%255;
			ary2[n++]=0;
			ary2[n++]=0;
			count++;
			if (count==m)
			{
				break;
			}
		case 2:
			ary2[n++]=0x02;//驱动电机数据
			ary2[n++]=1;//驱动电机个数
			ary2[n++]=1;//序号
			ary2[n++]=rand()%3+1;//状态
			ary2[n++]=rand()%250;//控制器温度
			ary2[n++]=rand()%254;
			ary2[n++]=rand()%255;//转速
			ary2[n++]=rand()%254;
			ary2[n++]=rand()%255;//转矩
			ary2[n++]=rand()%250;//温度
			ary2[n++]=rand()%233;
			ary2[n++]=rand()%255;//输入电压
			ary2[n++]=rand()%77;
			ary2[n++]=rand()%255;//母线电流
			count++;
			if (count==m)
			{
				break;
			}
		case 3:
		{	ary2[n++]=0x03;//燃料电池标识
			ary2[n++]=rand()%70;
			ary2[n++]=rand()%255;//燃料电池电压
			ary2[n++]=rand()%70;
			ary2[n++]=rand()%250;//燃料电池电流
			ary2[n++]=rand()%230;
			ary2[n++]=rand()%255;//燃料消耗率
			ary2[n++]=0;
			ary2[n++]=rand()%24+1;//温度探针总数
			int tz;
			tz=ary2[n-1];
			int wd;
			for (wd=0;wd<tz;wd++){
			ary2[n++]=rand()%240;
			wdtz[wd]=ary2[n-1];
			}
			int temp;
			int c=0;
			for(c=0;c<tz-1;c++)
			{
				if(wdtz[c]>wdtz[c+1])
				{			
				temp=wdtz[c];
				wdtz[c]=wdtz[c+1];
				wdtz[c+1]=temp;
				}
			}
			high_tz=wdtz[tz-1];
			for(c=0;c<tz-1;c++)
			{
				if(wdtz[c]<wdtz[c+1])
				{			
				temp=wdtz[c];
				wdtz[c]=wdtz[c+1];
				wdtz[c+1]=temp;
				}
			}
			low_tz=wdtz[tz-1];
			for(c=n-tz;c<n;c++){
				if (ary2[c]==high_tz){
					high_tznum=c-74;
				}
				if (ary2[c]==low_tz){
					low_tznum=c-74;
				}
			}
			ary2[n++]=((10*high_tz)>>8);
			ary2[n++]=(10*high_tz&0xff);//氢系统中最高温度
			ary2[n++]=high_tznum;//氢系统中最高温度探针代号
			ary2[n++]=rand()%233;
			ary2[n++]=rand()%255;//氢气最高浓度
			ary2[n++]=rand()%251+1;//氢气最高浓度代号
			ary2[n++]=rand()%61;
			ary2[n++]=rand()%255;//氢气最高压力
			ary2[n++]=rand()%251+1;//氢气最高压力传感器代号
			ary2[n++]=rand()%1+1;//高压DC/DC状态
			count++;
			if (count==m)
			{
				break;
			}
		}	
		case 4:
			ary2[n++]=0x04;//发动机数据标识
			ary2[n++]=0x01;//发动机状态
			ary2[n++]=rand()%233;
			ary2[n++]=rand()%255;//曲轴转速
			ary2[n++]=rand()%233;
			ary2[n++]=rand()%255;//燃料消耗率
			count++;
			if (count==m)
			{
				break;
			}
		case 5:
			ary2[n++]=0x05;//车辆位置标识
			ary2[n++]=0x07;//状态位
			ary2[n++]==rand()%9;
			ary2[n++]=rand()%255;
			ary2[n++]=rand()%255;
			ary2[n++]=rand()%255;//经度
			ary2[n++]==rand()%9;
			ary2[n++]=rand()%255;
			ary2[n++]=rand()%255;
			ary2[n++]=rand()%255;//纬度
			count++;
			if (count==m)
			{
				break;
			}
		case 6:
			ary2[n++]=0x06;//极值数据
			ary2[n++]==rand()%249+1;//最高电压子系统号
			ary2[n++]=rand()%249+1;//最高电压电池单体代号
			ary2[n++]=rand()%57;
			ary2[n++]=rand()%255;//电池单体电压最高值
			ary2[n++]==rand()%249+1;//最低电压子系统号
			ary2[n++]=rand()%249+1;//最低电压电池单体代号
			ary2[n++]=rand()%57;
			ary2[n++]=rand()%255;//电池单体电压最低值
			ary2[n++]==rand()%249+1;//最高温度系统号
			ary2[n++]=high_tznum;//最高温度探针号
			ary2[n++]=high_tz;//最高温度
			ary2[n++]==rand()%249+1;//最低温度系统号
			ary2[n++]=low_tznum;//最低温度探针号
			ary2[n++]=low_tz;//最低温度
			count++;
			if (count==m)
			{
				break;
			}
		case 7:
			ary2[n++]=0x07;//报警数据
			ary2[n++]==rand()%3;//最高报警等级
			ary2[n++]=0;
			ary2[n++]=rand()%3;
			ary2[n++]=rand()%255;
			ary2[n++]=rand()%255;//通用报警标志
			ary2[n++]=1;//可充电储能装置故障总数
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;//可充电储能装置故障代码列表
			ary2[n++]=1;//驱动电机故障总数
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;//驱动电机故障代码列表
			ary2[n++]=1;//发动机故障总数
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;//发动机故障代码列表
			ary2[n++]=1;//其他故障总数
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;//其它故障代码列表
			count++;
			if (count==m)
			{
				break;
			}
			break;
	}
	ary2[24]=0xFE;
	ary2[25]=0xFF;//数据单元长度
	int s5=ary2[0];
	int i;
	for (i = 2; i <n-1; i++)
    	{
    		s5^=ary2[i+1];
    	}
	ary2[n]=s5;//校验码
	send(sockfd,ary2,MAXBUF+1,0);
}

/************************************************************
*func:		test3()
*param:	
*descrp:	send
*author:	Darren
*date:		2019.7.11
*ver:		v1.0.0
*change:
************************************************************/
void test3()
{
	bzero(ary2,1025);
	memcpy(ary2,tcp_client.message_head(2),23*sizeof(char));
	time_t t;
	struct tm*lt;
	time (&t);//获取Unix时间戳
	lt = localtime(&t);
	ary2[24]=lt->tm_year-100;
	ary2[25]=lt->tm_mon+1;
	ary2[26]=lt->tm_mday;
	ary2[27]=lt->tm_hour;
	ary2[28]=lt->tm_min;
	ary2[29]=lt->tm_sec;//数据采集时间
	memcpy(ary2+30,tcp_client.message_head(2),23*sizeof(char));
	int n=53;
	ary2[n++]=lt->tm_year-100;
	ary2[n++]=lt->tm_mon+1;
	ary2[n++]=lt->tm_mday;
	ary2[n++]=lt->tm_hour;
	ary2[n++]=lt->tm_min;
	ary2[n++]=lt->tm_sec;//数据采集时间
	srand((unsigned int)time(NULL)); 
	int m=7;
	int count=0;
	int low_tznum,high_tznum,low_tz,high_tz;
	unsigned char wdtz[MAXBUF];
	switch (1)
	{
		case 1:
			ary2[n++]=0x01;//整车
			ary2[n++]=rand()%2+1;//车辆状态
			ary2[n++]=rand()%2+1;//充电状态
			ary2[n++]=rand()%2+1;//运行模式
			ary2[n++]=rand()%8;
			ary2[n++]=rand()%255;//车速
			ary2[n++]=0;
			ary2[n++]=rand()%255;
			ary2[n++]=rand()%255;
			ary2[n++]=rand()%255;//里程
			ary2[n++]=rand()%26;
			ary2[n++]=rand()%255;//总电压
			ary2[n++]=rand()%26;
			ary2[n++]=rand()%255;//总电流
			ary2[n++]=rand()%100;//soc
			ary2[n++]=rand()%1+1;//DC-DC状态
			ary2[n++]=rand()%15;//档位
			ary2[n++]=rand()%233;
			ary2[n++]=rand()%255;
			ary2[n++]=0;
			ary2[n++]=0;
			count++;
			if (count==m)
			{
				break;
			}
		case 2:
			ary2[n++]=0x02;//驱动电机数据
			ary2[n++]=1;//驱动电机个数
			ary2[n++]=1;//序号
			ary2[n++]=rand()%3+1;//状态
			ary2[n++]=rand()%250;//控制器温度
			ary2[n++]=rand()%254;
			ary2[n++]=rand()%255;//转速
			ary2[n++]=rand()%254;
			ary2[n++]=rand()%255;//转矩
			ary2[n++]=rand()%250;//温度
			ary2[n++]=rand()%233;
			ary2[n++]=rand()%255;//输入电压
			ary2[n++]=rand()%77;
			ary2[n++]=rand()%255;//母线电流
			count++;
			if (count==m)
			{
				break;
			}
		case 3:
		{	ary2[n++]=0x03;//燃料电池标识
			ary2[n++]=rand()%70;
			ary2[n++]=rand()%255;//燃料电池电压
			ary2[n++]=rand()%70;
			ary2[n++]=rand()%250;//燃料电池电流
			ary2[n++]=rand()%230;
			ary2[n++]=rand()%255;//燃料消耗率
			ary2[n++]=0;
			ary2[n++]=rand()%24+1;//温度探针总数
			int tz;
			tz=ary2[n-1];
			int wd;
			for (wd=0;wd<tz;wd++){
			ary2[n++]=rand()%240;
			wdtz[wd]=ary2[n-1];
			}
			int temp;
			int c=0;
			for(c=0;c<tz-1;c++)
			{
				if(wdtz[c]>wdtz[c+1])
				{			
				temp=wdtz[c];
				wdtz[c]=wdtz[c+1];
				wdtz[c+1]=temp;
				}
			}
			high_tz=wdtz[tz-1];
			for(c=0;c<tz-1;c++)
			{
				if(wdtz[c]<wdtz[c+1])
				{			
				temp=wdtz[c];
				wdtz[c]=wdtz[c+1];
				wdtz[c+1]=temp;
				}
			}
			low_tz=wdtz[tz-1];
			for(c=n-tz;c<n;c++){
				if (ary2[c]==high_tz){
					high_tznum=c-74;
				}
				if (ary2[c]==low_tz){
					low_tznum=c-74;
				}
			}
			ary2[n++]=((10*high_tz)>>8);
			ary2[n++]=(10*high_tz&0xff);//氢系统中最高温度
			ary2[n++]=high_tznum;//氢系统中最高温度探针代号
			ary2[n++]=rand()%233;
			ary2[n++]=rand()%255;//氢气最高浓度
			ary2[n++]=rand()%251+1;//氢气最高浓度代号
			ary2[n++]=rand()%61;
			ary2[n++]=rand()%255;//氢气最高压力
			ary2[n++]=rand()%251+1;//氢气最高压力传感器代号
			ary2[n++]=rand()%1+1;//高压DC/DC状态
			count++;
			if (count==m)
			{
				break;
			}
		}	
		case 4:
			ary2[n++]=0x04;//发动机数据标识
			ary2[n++]=0x01;//发动机状态
			ary2[n++]=rand()%233;
			ary2[n++]=rand()%255;//曲轴转速
			ary2[n++]=rand()%233;
			ary2[n++]=rand()%255;//燃料消耗率
			count++;
			if (count==m)
			{
				break;
			}
		case 5:
			ary2[n++]=0x05;//车辆位置标识
			ary2[n++]=0x07;//状态位
			ary2[n++]==rand()%9;
			ary2[n++]=rand()%255;
			ary2[n++]=rand()%255;
			ary2[n++]=rand()%255;//经度
			ary2[n++]==rand()%9;
			ary2[n++]=rand()%255;
			ary2[n++]=rand()%255;
			ary2[n++]=rand()%255;//纬度
			count++;
			if (count==m)
			{
				break;
			}
		case 6:
			ary2[n++]=0x06;//极值数据
			ary2[n++]==rand()%249+1;//最高电压子系统号
			ary2[n++]=rand()%249+1;//最高电压电池单体代号
			ary2[n++]=rand()%57;
			ary2[n++]=rand()%255;//电池单体电压最高值
			ary2[n++]==rand()%249+1;//最低电压子系统号
			ary2[n++]=rand()%249+1;//最低电压电池单体代号
			ary2[n++]=rand()%57;
			ary2[n++]=rand()%255;//电池单体电压最低值
			ary2[n++]==rand()%249+1;//最高温度系统号
			ary2[n++]=high_tznum;//最高温度探针号
			ary2[n++]=high_tz;//最高温度
			ary2[n++]==rand()%249+1;//最低温度系统号
			ary2[n++]=low_tznum;//最低温度探针号
			ary2[n++]=low_tz;//最低温度
			count++;
			if (count==m)
			{
				break;
			}
		case 7:
			ary2[n++]=0x07;//报警数据
			ary2[n++]==rand()%3;//最高报警等级
			ary2[n++]=0;
			ary2[n++]=rand()%3;
			ary2[n++]=rand()%255;
			ary2[n++]=rand()%255;//通用报警标志
			ary2[n++]=1;//可充电储能装置故障总数
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;//可充电储能装置故障代码列表
			ary2[n++]=1;//驱动电机故障总数
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;//驱动电机故障代码列表
			ary2[n++]=1;//发动机故障总数
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;//发动机故障代码列表
			ary2[n++]=1;//其他故障总数
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;
			ary2[n++]==rand()%5;//其它故障代码列表
			count++;
			if (count==m)
			{
				break;
			}
			break;
	}
	ary2[52]=0;
	ary2[53]=n-54;//数据单元长度
	printf("数据位长度：%d, n为：%d",ary2[53],n+1);
	int s5=ary2[0];
	int i;
	for (i = 2; i <n-1; i++)
    	{
    		s5^=ary2[i+1];
    	}
	ary2[n]=s5;//校验码
	send(sockfd,ary2,MAXBUF+1,0);
}

/************************************************************
*func:		test4()
*param:	
*descrp:	send
*author:	Darren
*date:		2019.7.11
*ver:		v1.0.0
*change:
************************************************************/
void test4()//分包发送
{
	unsigned char buffer1[2048];
	unsigned char buffer_2[512];
	unsigned char buffer3[512];
	unsigned char buffer4[512];
	int i = 0;
	///第一个包
	int data_start_bit = i;
	const char *s1="##";//开头
	memcpy(buffer1 + i, s1, 2*sizeof(char));
	i+=2;
	buffer1[i++]=0x01;//命令标识
	buffer1[i++] = 0xFE;//应答标志
	const char *s2="LFV2A2156C3333333";
	memcpy(buffer1+i,s2,17*sizeof(char));//唯一识别码
	i+=17;
	buffer1[i++]=0x01;//数据加密方式
	buffer1[i++]=0x07;
	buffer1[i++]=0xe7;//数据单元长度
	time_t t;
	struct tm*lt;
	time (&t);//获取Unix时间戳
	lt = localtime(&t);
	buffer1[i++]=lt->tm_year-100;
	buffer1[i++]=lt->tm_mon+1;
	buffer1[i++]=lt->tm_mday;
	buffer1[i++]=lt->tm_hour;
	buffer1[i++]=lt->tm_min;
	buffer1[i++]=lt->tm_sec;//数据采集时间
	buffer1[i++]=0;
	buffer1[i++]=1;//登ru流水号//buffer[31]
	const char *s3="83605337981605490187";
	memcpy(buffer1 + i, s3, 20*sizeof(char));//ICCID
	i += 20;
	buffer1[i++]=1;//可充电储能子系统数
	buffer1[i++]=12;//编码长度
	const char *s4="10fff01011ff";
	memcpy(buffer1 + i , s4, 12*sizeof(char));
	i += 12;

	for (int cc = 0; cc < 446; cc++)//data_length - 42
	{
		buffer1[i++] = 9;
	}
	send(sockfd, buffer1, 512, 0);
	if(send<0)
	{
		printf("发送失败");
	}
////////////////////////////////////////
	for (int cc = 0; cc < 512; ++cc)
	{
		buffer_2[cc] = 9;
		buffer1[i++] = 9;
	}
	send(sockfd, buffer_2, 512, 0);
///////////////////////////////////////
	for (int cc = 0; cc < 512; ++cc)
	{
		buffer3[cc] = 9;
		buffer1[i++] = 9;
	}
	send(sockfd, buffer3, 512, 0);
/////////////////////////////////////
	for (int cc = 0; cc < 511; ++cc)
	{
		buffer4[cc] = 9;
		buffer1[i++] = 9;
	}
	int BCC_code=buffer1[0];
	for (i = 1; i < 2047; i++)
    {
   		BCC_code^=buffer1[i];
   	}
   	printf("第%d位的BCC校验码%d\n",i+1,BCC_code );
   	buffer4[511] = BCC_code;
   	send(sockfd, buffer4, 512, 0);
	printf("分包发送成功\n");
}

void test5()
{
	unsigned char buffer1[1024];
	int i = 0;
	///第一个包
	int data_start_bit = 0;
	data_start_bit = i;
	const char *s1="##";//开头
	memcpy(buffer1 + i, s1, 2*sizeof(char));
	i+=2;
	buffer1[i++]=0x02;//命令标识
	buffer1[i++] = 0xFE;//应答标志
	const char *s2="LFV2A2156C3333333";
	memcpy(buffer1+i,s2,17*sizeof(char));//唯一识别码
	i+=17;
	buffer1[i++]=0x01;//数据加密方式
	buffer1[i++]=0x00;
	buffer1[i++]=0xff;//数据单元长度
	time_t t;
	struct tm*lt;
	time (&t);//获取Unix时间戳
	lt = localtime(&t);
	//printf("tiem_front:%d\n", i);
	buffer1[i++]=lt->tm_year-100;
	buffer1[i++]=lt->tm_mon+1;
	buffer1[i++]=lt->tm_mday;
	buffer1[i++]=lt->tm_hour;
	buffer1[i++]=lt->tm_min;
	buffer1[i++]=lt->tm_sec;//数据采集时间
	buffer1[i++]=0;
	buffer1[i++]=1;//登ru流水号//buffer[31]
	const char *s3="83605337981605490187";
	memcpy(buffer1 + i, s3, 20*sizeof(char));//ICCID
	i += 20;
	buffer1[i++]=1;//可充电储能子系统数
	buffer1[i++]=12;//编码长度
	const char *s4="10fff01011ff";
	memcpy(buffer1 + i , s4, 12*sizeof(char));
	i += 12;
	for (int cc = 0; cc < 213; cc++)//data_length - 42
	{
		buffer1[i++] = cc;
	}
	int k;
	int buf_length = buffer1[data_start_bit + 23] + 25;		
	int BCC_code_resp=buffer1[data_start_bit];
	for (k = 0; k < buf_length-2; k++)
   	{       
   		BCC_code_resp^=buffer1[data_start_bit+k+1];
   	}
   	buffer1[i++] = BCC_code_resp;
///////////////////////////////////////////////
   	//////////第二个包
	data_start_bit = i;
	memcpy(buffer1 + i, s1, 2*sizeof(char));
	i+=2;
	buffer1[i++]=0x02;//命令标识
	buffer1[i++] = 0xFE;//应答标志
	memcpy(buffer1+i,s2,17*sizeof(char));//唯一识别码
	i+=17;
	buffer1[i++]=0x01;//数据加密方式
	buffer1[i++]=0x00;
	buffer1[i++]=0xff;//数据单元长度
	lt = localtime(&t);
	//printf("tiem_front:%d\n", i);
	buffer1[i++]=lt->tm_year-100;
	buffer1[i++]=lt->tm_mon+1;
	buffer1[i++]=lt->tm_mday;
	buffer1[i++]=lt->tm_hour;
	buffer1[i++]=lt->tm_min;
	buffer1[i++]=lt->tm_sec;//数据采集时间
	buffer1[i++]=0;
	buffer1[i++]=1;//登ru流水号//buffer[31]
	memcpy(buffer1 + i, s3, 20*sizeof(char));//ICCID
	i += 20;
	buffer1[i++]=1;//可充电储能子系统数
	buffer1[i++]=12;//编码长度
	memcpy(buffer1 + i , s4, 12*sizeof(char));
	i += 12;
	for (int cc = 0; cc < 213; cc++)//data_length - 42
	{
		buffer1[i++] = cc;
	}
	buf_length = buffer1[data_start_bit + 23] + 25;		
	BCC_code_resp=buffer1[data_start_bit];
	for (k = 0; k < buf_length-2; k++)
   	{       
   		BCC_code_resp^=buffer1[data_start_bit+k+1];
   	}
   	buffer1[i++] = BCC_code_resp;
   	/////////////////////
   	///////////第三个包
   	////////////
   		data_start_bit = i;
	memcpy(buffer1 + i, s1, 2*sizeof(char));
	i+=2;
	buffer1[i++]=0x02;//命令标识
	buffer1[i++] = 0xFE;//应答标志
	memcpy(buffer1+i,s2,17*sizeof(char));//唯一识别码
	i+=17;
	buffer1[i++]=0x01;//数据加密方式
	buffer1[i++]=0x00;
	buffer1[i++]=0xff;//数据单元长度
	lt = localtime(&t);
	//printf("tiem_front:%d\n", i);
	buffer1[i++]=lt->tm_year-100;
	buffer1[i++]=lt->tm_mon+1;
	buffer1[i++]=lt->tm_mday;
	buffer1[i++]=lt->tm_hour;
	buffer1[i++]=lt->tm_min;
	buffer1[i++]=lt->tm_sec;//数据采集时间
	buffer1[i++]=0;
	buffer1[i++]=1;//登ru流水号//buffer[31]
	memcpy(buffer1 + i, s3, 20*sizeof(char));//ICCID
	i += 20;
	buffer1[i++]=1;//可充电储能子系统数
	buffer1[i++]=12;//编码长度
	memcpy(buffer1 + i , s4, 12*sizeof(char));
	i += 12;
	for (int cc = 0; cc < 213; cc++)//data_length - 42
	{
		buffer1[i++] = cc;
	}
	buf_length = buffer1[data_start_bit + 23] + 25;		
	BCC_code_resp=buffer1[data_start_bit];
	for (k = 0; k < buf_length-2; k++)
   	{       
   		BCC_code_resp^=buffer1[data_start_bit+k+1];
   	}
   	buffer1[i++] = BCC_code_resp;
   	////////////////////////////
   	/////////////////////////////发送
	for(int n=0;n<20;n++)
	{
		send(sockfd, buffer1, 1024, 0);
		usleep(10000);
	}
	sleep(10);
	for(int n=0;n<20;n++)
	{
		send(sockfd, buffer1, 1024, 0);
		usleep(10000);
	}
	sleep(10);
	for(int n=0;n<20;n++)
	{
		send(sockfd, buffer1, 1024, 0);
		usleep(10000);
	}
	printf("快速发包，发送成功\n");
	//////////////////////////////////////////////////发送
}

void test6()
{
	unsigned char buf[MAXBUF];
	memcpy(buf,tcp_client.message_head(0x10),23*sizeof(char));
	time_t t;
	struct tm*lt;
	time (&t);
	lt = localtime(&t);
	buf[24] = lt->tm_year-100;
	buf[25] = lt->tm_mon+1;
	buf[26] = lt->tm_mday;
	buf[27] = lt->tm_hour;
	buf[28] = lt->tm_min;
	buf[29] = lt->tm_sec;//数据采集时间
	int i = 30;
	const char *s2 = "ftp://192.168.43.214:23666";
	memcpy(buf + i, s2, 26*sizeof(char));//拨号点名称
	i+=26;
	int buf_length = i+1;
	buf[23] =buf_length -25;//data_length
	printf("%d\n", buf[23]);
	int k;
	int BCC_code_resp=buf[0];
	for (k = 0; k < buf_length-2; k++)
   	{       
   		BCC_code_resp^=buf[k+1];
   	}
	buf[i] = BCC_code_resp;
	send(sockfd, buf, MAXBUF, 0);
	printf("send upload message!\n");
}