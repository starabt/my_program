#include "tcp_client.h"
extern char *IP;
extern char *port;

/************************************************************
*func:		Log()
*param:		
*descrp:	初始化日志
*author:	Darren
*date:		2019.8.21
*ver:		v1.0.0
*change:        
************************************************************/
Log::Log()
{
	//printf("初始化日志存储\n");
}

/************************************************************
*func:		Log()
*param:		
*descrp:	初始化日志
*author:	Darren
*date:		2019.8.21
*ver:		v1.0.0
*change:        
************************************************************/
Log::~Log()
{

}

/************************************************************
*func:		save_normal_log()
*param:		unsigned char bufferb[]
*descrp:	存储报文数据
*author:	Darren
*date:		2019.8.19
*ver:		v1.0.0
*change:        
************************************************************/
void Log::save_normal_log(unsigned char bufferb[])
{
	buf_length=((bufferb[22]<<8)+bufferb[23]+25);
   	unsigned char buffer[buf_length];
   	bzero(buffer,buf_length);
   	memcpy(buffer,bufferb,buf_length);
	int order_sign = buffer[2];
	switch(order_sign)	
	{
		case 0x01:	save_log_login(buffer);break;//登入日志
		case 0x02:	save_log_data(buffer);break;//实时信息日志
		case 0x04:	save_log_logout(buffer);break;//登出日志
		case 0x82:	save_log_upgrade(buffer);break;//升级日志
		default:	printf("未知命令！\n");
	}
}

/************************************************************
*func:		save_log_login()
*param:		unsigned char buf[]
*descrp:	存储登录报文数据
*author:	Darren
*date:		2019.8.19
*ver:		v1.0.0
*change:        
************************************************************/
int Log::save_log_login(unsigned char buf[])
{
	FILE *fp ;
	time_t timer;//取当前时间
	struct tm t_tm;
	time(&timer);
	localtime_r(&timer, &t_tm);
	select_worklog_filename(t_tm);
	fp=fopen("log/work_log/today", "a+" );
	if ( fp == NULL )
	{
		printf("打开实时数据存储文件失败!\n");
		return -1;
	}
	
	fprintf(fp,"[login] [%4d/%02d/%02d %02d:%02d:%02d\r]", t_tm.tm_year+1900,t_tm.tm_mon+1, t_tm.tm_mday, t_tm.tm_hour, t_tm.tm_min, t_tm.tm_sec);
	fprintf(fp,"[IP:%s port:%s]\r",IP,port);
	for (int i = 0; i < buf_length; ++i)
	{
		fprintf(fp,"%x",buf[i]);
	}
	fprintf(fp, "\n");
	printf("登录日志存储成功！\n");
	fclose(fp);
	return 0;
}

/************************************************************
*func:		select_worklog_filename()
*param:		unsigned char bufferb[]
*descrp:	选择工作日志文件名
*author:	Darren
*date:		2019.9.19
*ver:		v1.0.0
*change:        
************************************************************/
void Log::select_worklog_filename(struct tm t_tm)
{
	struct stat mystat;
	int check_day = stat("log/work_log/today",&mystat);
	if (check_day == 0)
	{
		struct tm data_tm;
		localtime_r(&mystat.st_mtime, &data_tm);
		if ((data_tm.tm_year != t_tm.tm_year)|| (data_tm.tm_mon != t_tm.tm_mon) || (data_tm.tm_mday != t_tm.tm_mday) || (data_tm.tm_hour != t_tm.tm_hour) || (data_tm.tm_min != t_tm.tm_min))
		{
			//printf("data_tm:%d\n", data_tm.tm_min);
			//printf("t_tm:%d\n", t_tm.tm_min);
			printf("更改文件路径\n");
			rename("log/work_log/5daysago","log/work_log/6daysago");
			rename("log/work_log/4daysago","log/work_log/5daysago");
			rename("log/work_log/3daysago","log/work_log/4daysago");
			rename("log/work_log/2daysago","log/work_log/3daysago");
			rename("log/work_log/1dayago","log/work_log/2daysago");
			rename("log/work_log/today","log/work_log/1dayago");
		}
	}
}

/************************************************************
*func:		save_log_logout()
*param:		unsigned char buf[]
*descrp:	存储登出报文数据
*author:	Darren
*date:		2019.8.19
*ver:		v1.0.0
*change:        
************************************************************/
int Log::save_log_logout(unsigned char buf[])
{
	FILE *fp;
	time_t timer;
	struct tm t_tm;
	time(&timer);
	localtime_r(&timer, &t_tm);
	select_worklog_filename(t_tm);
	fp=fopen("log/work_log/today", "a+" );
	if ( fp == NULL )
	{
		printf("打开实时数据存储文件失败!\n");
		return -1;
	}
	fprintf(fp,"[logout] [%4d/%02d/%02d %02d:%02d:%02d]\r", t_tm.tm_year+1900,t_tm.tm_mon+1, t_tm.tm_mday, t_tm.tm_hour, t_tm.tm_min, t_tm.tm_sec);
	fprintf(fp,"[IP:%s port:%s]\r",IP,port);
	for (int i = 0; i < buf_length; ++i)
	{
		fprintf(fp,"%x",buf[i]);
	}
	fprintf(fp, "\n");
	fclose(fp);
	return 0;
}

/************************************************************
*func:		save_log_upgrade()
*param:		unsigned char buf[]
*descrp:	存储升级报文数据
*author:	Darren
*date:		2019.8.19
*ver:		v1.0.0
*change:
************************************************************/
int Log::save_log_upgrade(unsigned char buf[])
{
	FILE *fp;
	time_t timer;
	struct tm t_tm;
	time(&timer);
	localtime_r(&timer, &t_tm);
	select_worklog_filename(t_tm);
	fp=fopen("log/work_log/today", "a+" );
	fprintf(fp,"[upgrade] [%4d/%02d/%02d %02d:%02d:%02d]\r", t_tm.tm_year+1900,t_tm.tm_mon+1, t_tm.tm_mday, t_tm.tm_hour, t_tm.tm_min, t_tm.tm_sec);
	fprintf(fp,"[IP:%s port:%s]\r",IP,port);
	for (int i = 0; i < buf_length; ++i)
	{
		fprintf(fp,"%x",buf[i]);
	}
	fprintf(fp, "\n");
	printf("实时数据存储成功！\n");
	fclose(fp);
	return 0;
}

/************************************************************
*func:		select_datalog_filename()
*param:		unsigned char bufferb[]
*descrp:	选择数据日志文件名
*author:	Darren
*date:		2019.8.20
*ver:		v1.0.0
*change:        
************************************************************/
void Log::select_datalog_filename(struct tm t_tm)
{
	struct stat mystat;
	int check_day = stat("log/data_log/today",&mystat);
	if (check_day == 0)
	{
		struct tm data_tm;
		localtime_r(&mystat.st_mtime, &data_tm);
		if ((data_tm.tm_year != t_tm.tm_year)|| (data_tm.tm_mon != t_tm.tm_mon) || (data_tm.tm_mday != t_tm.tm_mday) || (data_tm.tm_hour != t_tm.tm_hour) || (data_tm.tm_min != t_tm.tm_min))
		{
			printf("data_tm:%d\n", data_tm.tm_min);
			printf("t_tm:%d\n", t_tm.tm_min);
			printf("更改文件路径\n");
			rename("log/data_log/5daysago","log/data_log/6daysago");
			rename("log/data_log/4daysago","log/data_log/5daysago");
			rename("log/data_log/3daysago","log/data_log/4daysago");
			rename("log/data_log/2daysago","log/data_log/3daysago");
			rename("log/data_log/1dayago","log/data_log/2daysago");
			rename("log/data_log/today","log/data_log/1dayago");
		}
	}
}

/************************************************************
*func:		save_log_data()
*param:		unsigned char buf[]
*descrp:	存储实时数据报文数据
*author:	Darren
*date:		2019.8.19
*ver:		v1.0.0
*change:
************************************************************/
int Log::save_log_data(unsigned char buf[])
{
	time_t timer;
	struct tm t_tm;
	time(&timer);
	localtime_r(&timer, &t_tm);
	printf("开始写入: %4d/%02d/%02d %02d:%02d:%02d\n", t_tm.tm_year+1900,t_tm.tm_mon+1, t_tm.tm_mday, t_tm.tm_hour, t_tm.tm_min, t_tm.tm_sec);
	select_datalog_filename(t_tm);
	FILE *fp;
	fp=fopen("log/data_log/today" , "a+" );
	if ( fp == NULL )
	{
		printf("打开实时数据存储文件失败!\n");
		return -1;
	}
	fprintf(fp,"[data] [%4d/%02d/%02d %02d:%02d:%02d]\r", t_tm.tm_year+1900,t_tm.tm_mon+1, t_tm.tm_mday, t_tm.tm_hour, t_tm.tm_min, t_tm.tm_sec);
	fprintf(fp,"[IP:%s port:%s]\r",IP,port);
	for (int i = 0; i < buf_length; ++i)
	{
		fprintf(fp,"%x",buf[i]);
	}
	fprintf(fp, "\n");
	printf("实时数据存储成功！\n");
	time(&timer);
	localtime_r(&timer, &t_tm);
	printf("写入完成: %4d/%02d/%02d %02d:%02d:%02d\n", t_tm.tm_year+1900,t_tm.tm_mon+1, t_tm.tm_mday, t_tm.tm_hour, t_tm.tm_min, t_tm.tm_sec);
	fclose(fp);
	return 0;
}

/************************************************************
*func:		save_error_log()
*param:		int 
*descrp:	存储登出报文数据
*author:	Darren
*date:		2019.8.19
*ver:		v1.0.0
*change:        
************************************************************/
int TCP_CLIENT::save_error_log(char *msg)
{
	FILE *fp;
	time_t timer;
	struct tm t_tm;
	time(&timer);
	localtime_r(&timer, &t_tm);
	struct stat mystat;
	int check_day = stat("log/error_log/today",&mystat);
	if (check_day == 0)
	{
		struct tm data_tm;
		localtime_r(&mystat.st_mtime, &data_tm);
		if ((data_tm.tm_year != t_tm.tm_year)|| (data_tm.tm_mon != t_tm.tm_mon) || (data_tm.tm_mday != t_tm.tm_mday) )
		{
			printf("data_tm:%d\n", data_tm.tm_min);
			printf("t_tm:%d\n", t_tm.tm_min);
			printf("更改文件路径\n");
			rename("log/error_log/5daysago","log/error_log/6daysago");
			rename("log/error_log/4daysago","log/error_log/5daysago");
			rename("log/error_log/3daysago","log/error_log/4daysago");
			rename("log/error_log/2daysago","log/error_log/3daysago");
			rename("log/error_log/1dayago","log/error_log/2daysago");
			rename("log/error_log/today","log/error_log/1dayago");
		}
	}
	fp=fopen("log/error_log/today" , "a+" );
	if ( fp == NULL )
	{
		printf("打开实时数据存储文件失败!\n");
		return -1;
	}
	fprintf(fp,"[error] [%4d/%02d/%02d %02d:%02d:%02d]\r", t_tm.tm_year+1900,t_tm.tm_mon+1, t_tm.tm_mday, t_tm.tm_hour, t_tm.tm_min, t_tm.tm_sec);
	fprintf(fp, "%s", msg);
}