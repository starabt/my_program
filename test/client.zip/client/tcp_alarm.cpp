#include "tcp_client.h"
extern List * alarmhead;

/************************************************************
*func:		data_getLength()
*param:	
*descrp:	check the length of the data saved
*author:	Darren
*date:		2019.7.26
*ver:		v1.0.0
*change:
************************************************************/
int TCP_CLIENT::data_getLength()
{
	int count = 0;                  //定义count计数
	List *p = alarmhead->next;           //定义p指向头结点
	while (p != NULL)                //当指针的下一个地址不为空时，count+1
	{
		count++;                  
		p = p->next;                //p指向p的下一个地址
	}
	return count;                   //返回count的数据
}

/************************************************************
*func:		data_save()
*param:	unsigned char []
*descrp:	save data
*author:	Darren
*date:		2019.7.26
*ver:		v1.0.0
*change:
************************************************************/
void TCP_CLIENT::data_save(unsigned char buf[])
{
	buf[2]=3;
	int buf_length=((buf[22]<<8)+buf[23]+25);
	int i;
	int BCC_code=buf[0];
	for (i = 0; i < buf_length-2; i++)
    {
   		BCC_code^=buf[i+1];
   	}
   	buf[buf_length-1]=BCC_code;
	List pdata;
	memcpy(pdata.tcp_data,buf,MAXBUF);
	List * newNode = new List;    //定义一个Node结点指针newNode
	memcpy(newNode->tcp_data,pdata.tcp_data,MAXBUF);
	List * p = alarmhead;              //定义指针p指向头结点
	if (alarmhead == NULL) {           //当头结点为空时，设置newNode为头结点
	    alarmhead = newNode;
	}
	newNode->next = p->next;          //将新节点插入到指定位置
	p->next = newNode;
	if (data_getLength()>30)
	{
		data_delete();
	}
}

/************************************************************
*func:		data_delete()
*param:	
*descrp:	delete the end of the data saved
*author:	Darren
*date:		2019.7.26
*ver:		v1.0.0
*change:
************************************************************/
void TCP_CLIENT::data_delete()
{
	List * p = alarmhead;          //创建一个指针指向头结点
	List * ptemp = NULL;      //创建一个占位节点
	if (p->next == NULL) {        //判断链表是否为空
		cout << "the data saved is empty" << endl;
	}
	else
	{
		while (p->next != NULL)   //循环到尾部的前一个
		{
			ptemp = p;            //将ptemp指向尾部的前一个节点
			p = p->next;          //p指向最后一个节点
		}
		delete p;                //删除尾部节点
		p = NULL;
		ptemp->next = NULL;
	}
}

/************************************************************
*func:		send_previous_data()
*param:	
*descrp:	send data of previous 30s
*author:	Darren
*date:		2019.7.22
*ver:		v1.0.0
*change:
************************************************************/
void TCP_CLIENT::send_previous_data()
{
	unsigned char buffer4[MAXBUF+1];
	if (alarmhead == NULL || alarmhead->next ==NULL) {
	cout << "no prevous data" << endl;
	}
	List *p = alarmhead;                 //另指针指向头结点
	while (p->next != NULL)        //当指针的下一个地址不为空时，循环输出p的数据域
	{
		p = p->next;               //p指向p的下一个地址
		bzero (buffer4,MAXBUF+1);
		for (int  j=0;j<MAXBUF+1;j++)
		{
			buffer4[j]=p->tcp_data[j];
		}
		send_buftosend(buffer4);
	}
}