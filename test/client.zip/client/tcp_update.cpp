#include "tcp_client.h"
#define BUFFER_SIZE 1024
int data_sockfd;
extern char *IP;
extern char *port;
char TCP_CONNECT_IP[256];
extern int len,sockfd;
extern Log log;
/************************************************************
*func:		respond_upgrade()
*param:		unsigned char []
*descrp:	升级
*author:	Darren
*date:		2019.8.3
*ver:		v1.0.0
*change:
************************************************************/
void TCP_CLIENT::respond_upgrade(unsigned char buffera[])
{
	int respond_sign=buffera[3];
	switch(respond_sign)	
	{
		case 0xfe:
			{
				printf("\n");
				printf("*************************开始升级！*************************\n");
				if(login_tcp(buffera)==-1)
				{
					printf("传输端口登入失败\n");
					break;
				}
				printf("**********************登入传输端口完成！**********************\n");
				/*char pathname[256];
				bzero(pathname,256);
				int code_startflag,i,j;
				int buf_data_num=((buffera[22]<<8)+buffera[23]+25);
				for (code_startflag=0,i = 38,j=0; i<buf_data_num-1; ++i)
				{
					if (buffera[i-1]=='/')
						code_startflag++;
					if (code_startflag==2)
					{
						pathname[j++]=buffera[i];
					}
				}
				printf("pathname:%s\n",pathname);*/
				int download_sign =tcp_download(data_sockfd);
				if(download_sign==-1)
				{
					printf("文件下载失败\n");
					unsigned char buf1[1025];
					bzero(buf1,1025);
					memcpy(buf1,buffera,1025);
					buf1[3]=0x02;
					len =send(sockfd,buf1,1025,0);
					if(len<0)
					{
						perror("send");
					}
					break;
				}
				if(download_sign==0)
				{	
					printf("*************************文件下载成功！*************************\n");
					unsigned char buf2[1025];
					bzero(buf2,1025);
					memcpy(buf2,buffera,1025);
					buf2[3]=0x01;
					len =send(sockfd,buf2,1025,0);
					if(len<0)
					{
						perror("send");
					}
					log.save_normal_log(buffera);
					//client_restart();
					break;
				}
			}
		case 0x02:	printf("发送数据错误！\n");break;
		case 0x03:	printf("发送数据重复！\n");break;
		case 0x01:	printf("所接收数据为应答指示！\n");break;
		default:	printf("数据错误！\n");
	}
}
/************************************************************
*func:		login_tcp()
*param:	
*descrp:	login tcp server
*author:	Darren
*date:		2019.8.6
*ver:		v1.0.0
*change:
************************************************************/
int TCP_CLIENT::login_tcp(unsigned char buffera[])
{
	char SERV_PORT[256];
	char tcp_user[256];
	char tcp_code[256];
	bzero (TCP_CONNECT_IP,256);
	bzero(SERV_PORT,256);
	bzero(tcp_user,256);
	bzero(tcp_code,256);
	int i;
	int j;
	int code_startflag;
	int code_endflag;
	for (i=38,j=0; buffera[i]!=':'; ++i,++j)
	{
		tcp_user[j]=buffera[i];
	}
	for (int code_startflag=0,i = 38,j=0; buffera[i]!='@'; ++i)
	{
		if (buffera[i-1]==':')
			code_startflag=1;
		if (code_startflag==1)
		{
			tcp_code[j++]=buffera[i];
		}
	}
	for (code_startflag=0,code_endflag=0,i = 38,j=0; code_endflag<2; ++i)
	{
		if (buffera[i+1]==':')
			code_endflag++;
		if (buffera[i-1]=='@')
			code_startflag=1;
		if (code_startflag==1)
			TCP_CONNECT_IP[j++]=buffera[i];
	}
	for (code_startflag=0,code_endflag=0,i = 38,j=0; code_endflag<1; ++i)
	{
		if (buffera[i+1]=='/')
			code_endflag++;
		if (buffera[i-1]==':')
		{
			code_startflag++;
		}
		if (code_startflag==2)
		{
			SERV_PORT[j++]=buffera[i];
		}
	}

	printf("tcp_user:%s\n",tcp_user);
	printf("tcp_code:%s\n",tcp_code );
	printf("TCP_CONNECT_IP:%s\n",TCP_CONNECT_IP );
	printf("SERV_PORT:%s\n",SERV_PORT );
	//获取hostent中相关参数
	struct sockaddr_in serv_addr;
 	char senddate,recvdate;
 	char sendline[MAXBUF],recvline[MAXBUF];
 	struct hostent *host;
 	fflush(stdout);
 	//创建socket
 	if( (data_sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0){
	 	printf("create socket error: %s(errno: %d)\n", strerror(errno),errno);
	 	return -1 ;
 	}
 	memset(&serv_addr, 0, sizeof(serv_addr));
 	serv_addr.sin_family=AF_INET;
 	serv_addr.sin_port=htons(atoi(SERV_PORT));
 	serv_addr.sin_addr.s_addr=INADDR_ANY;
 	//点分十进制转化为二进制整数地址
 	if(inet_pton(AF_INET, TCP_CONNECT_IP, &serv_addr.sin_addr) <= 0){
 	printf("inet_pton error for %s\n", TCP_CONNECT_IP);
 	close(data_sockfd);
 	return -1 ;
 	}
 	//调用connect函数发起连接
 	if((connect(data_sockfd,(struct sockaddr*)&serv_addr,sizeof(serv_addr)))<0)
 	{
	 	printf("连接失败\n");
	 	return -1;
 	}
 	recvdate=recv(data_sockfd,recvline,sizeof(recvline),0);
 	if(recvdate==-1)
 	{
	 	printf("recvdate is connect error/n");
	 	return -1;
 	}
 	else if(strncmp(recvline,"220",3)==0)
 	{
	 	printf("220 连接成功\n");
 	}
 	else
 	{
	 	printf("220 connect is error!");
	 	return -1;
 	}
 	//tcp用户登录主体部分，输入用户名
 	int sendbytes,recvbytes;
 	bzero(recvline,1024);
 	bzero(sendline,1024);
 	printf("自动登录 输入用户名中\n") ;
 	strcat(sendline,"USER ");
 	strcat(sendline,tcp_user);
 	strcat(sendline,"\r\n");
 	printf("--->%s\n",sendline);
 	sendbytes=send(data_sockfd,sendline,strlen(sendline),0);
 	if(sendbytes==-1)
 	{
	 	printf("send is wrong\n");
	 	return -1;
 	}
 	//输入密码
 	recvbytes=recv(data_sockfd,recvline,sizeof(recvline),0);
 	if(strncmp(recvline,"331",3)==0)
 	{
	 	printf("自动输入密码中\n");
 	}
 	else
 	{
	 	printf("recv date is error./n");
	 	return -1;
 	}
 	bzero(sendline,1024);
 	bzero(recvline,1024);
 	strcat(sendline,"PASS ");
 	strcat(sendline,tcp_code);
 	strcat(sendline,"\r\n");
 	printf("--->%s\n",sendline);
 	sendbytes=send(data_sockfd,sendline,strlen(sendline),0);
 	if(sendbytes==-1)
 	{
	 	printf("pass send is error\n");
	 	return -1;
 	}
 	recvbytes=recv(data_sockfd,recvline,sizeof(recvline),0);
 	if(strncmp(recvline,"230",3)==0)
 	{
	 	printf("登录成功!\n");
	 	return 0;
 	}
 	else
 	{
	 	printf("pass recv is error\n");
	 	return -1;
 	}
}

/************************************************************
*func:		unsigned long check_filesize()
*param:		data_sockfd,pathname
*descrp:	通过tcp下载文件
*author:	Darren
*date:		2019.8.17
*ver:		v1.0.0
*change:
************************************************************/
unsigned long TCP_CLIENT::check_filesize(char buffer_add[])
{
	FILE *fp;
	if((fp=fopen(buffer_add, "r+"))==NULL) return 0;
	fseek(fp, 0L, SEEK_END);
	unsigned long filesize = -1;
	filesize = ftell(fp);
    fclose(fp);
    return filesize;
}

/************************************************************
*func:		tcp_download()
*param:		data_sockfd,pathname
*descrp:	通过tcp下载文件
*author:	Darren
*date:		2019.8.6
*ver:		v1.0.0
*change:
************************************************************/
int TCP_CLIENT::tcp_download(int s)
{
	ssize_t size = 0;
	char buffer[BUFFER_SIZE];
	FILE *stream;
	strcpy(buffer,"请输入传输的文件路径：\n");
	write(s, buffer, BUFFER_SIZE);
	int length=0;
	char buffer_add[BUFFER_SIZE]={'\0'};
	for(;;)
	{
		size = read(s, buffer, BUFFER_SIZE-length);
		if(size <= 0){
			return -1;
		}
		strcat(buffer_add, buffer);
		length+=size;
		if(length>=BUFFER_SIZE) break;
	}
	unsigned char buffer2[4];
	bzero(buffer2,BUFFER_SIZE);
	unsigned long file_size=check_filesize(buffer_add);
	buffer2[0] =  	(file_size>>24);//最高1位字节
	buffer2[1] =	(file_size>>16)%256;
	buffer2[2] =	(file_size>>8)%256;
	buffer2[3] =	file_size%256;//最低字节
	printf("check existed filesize:%ld",file_size);
	write(s, buffer2, 4);
	if((stream=fopen(buffer_add, "a+"))==NULL) return -1;
	for(;;)
	{
		size = read(s, buffer, BUFFER_SIZE);
		if(size <= 0){
			break;
		}
		int write_len=fwrite(buffer, sizeof(char), size, stream);
	}
	fclose(stream);
	return 0;
}
/************************************************************
*func:		tcp_download()
*param:		data_sockfd,pathname
*descrp:	通过tcp下载文件
*author:	Darren
*date:		2019.8.6
*ver:		v1.0.0
*change:
************************************************************/
/*int tcp_download(int data_sockfd,char pathname[])
{
 	 
 	int pasv_or_port;// 定义the ftp协议的两种不同工作mode
 	int recvbytes,sendbytes;
 	int npsupport=1;
 	char recvline[1024];
 	struct sockaddr_in serv_addr;
 	FILE *fd;
 	int i,j;
 	bzero(recvline,1024);
 	//open the file
 	int size;
 	char localpathname[60];//预打开的文件路径字符串
 	int flags;
 	unsigned int mode;
 	bzero(recvline,1024);
 	//选择要下载的本地地址
 	strcat(localpathname,"client1");
 	fd=fopen(localpathname,"w+");
 	if(fd==NULL)
 	{
	 	printf("cannot open file\n");
	 	return -1;
 	} 	 
 	//begin to transport data
 	usleep(2000);
 	int flag=0;
 	char buf[65536];
 	recvdata:
 	bzero(buf,1024);
 	recvbytes=recv(data_sockfd,buf,sizeof(buf),0);
 	if(recvbytes<0)
 	{
	 	close(data_sockfd);
	 	goto end;
 	}
 	fwrite(buf,1,recvbytes,fd);
 	bzero(recvline,1024);
 	recvbytes=recv(data_sockfd,recvline,sizeof(recvline),0);
 	if(flag==0)
 	{
	 	if(strncmp(recvline,"226",3)!=0)
	 	{
		 	flag=1;
		 	goto recvdata;
	 	}
 	}
 	end:
 	if(flag!=1)
 	{
	 	bzero(recvline,1024);
	 	shutdown(data_sockfd,SHUT_WR);
	 	close(data_sockfd);
 	}
 	close(data_sockfd);
 	return 0;
}
*/
/************************************************************
*func:		client_restart()
*param:	
*descrp:	restart the client
*author:	Darren
*date:		2019.8.14
*ver:		v1.0.0
*change:
************************************************************/
void TCP_CLIENT::client_restart()
{
	printf("******************************重启中******************************\n");
	system("rm client\nmv client1 client\nsudo ./client 192.168.43.222 10222");
	exit(0); 
}
