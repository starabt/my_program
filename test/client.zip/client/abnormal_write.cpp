#include "tcp_client.h"
#include <fcntl.h>
extern List * sendhead;
/************************************************************
*func:		int datasave_abnormal()
*param:		unsigned char buf[]
*descrp:	网络异常时，存储实时数据至文件中
*author:	Darren
*date:		2019.8.15
*ver:		v1.0.0
*change:
************************************************************/
int TCP_CLIENT::datasave_abnormal(unsigned char buf[])
{
	buf[2]=3;
	int buf_length=((buf[22]<<8)+buf[23]+25);
	int i;
	int BCC_code=buf[0];
	for (i = 0; i < buf_length-2; i++)
    {
   		BCC_code^=buf[i+1];
   	}
   	buf[buf_length-1]=BCC_code;
	FILE *fp ;
	fp=fopen("abnormal_save" , "a+" );
	if ( fp == NULL )
	{
		printf("打开实时数据存储文件失败!\n");
		return -1;
	}
	for (int i= 0; i<150; i++)
	{
		printf("%x", buf[i]);
	}
	printf("\n");
	fwrite( buf, 1 , MAXBUF+1, fp ); //将数组写入文件
	printf("存储数据中\n");
	fclose(fp);
	return 0;
}

/************************************************************
*func:		int datasend_abnormal()
*param:		
*descrp:	补发网络异常时的实时数据给服务器
*author:	Darren
*date:		2019.8.15
*ver:		v1.0.0
*change:
************************************************************/
void *datasend_abnormal(void *)
{
	FILE *fp ;
	fp=fopen("abnormal_save" , "r+" );
	if ( fp == NULL )
	{
		printf("打开实时数据存储文件失败!\n");
		goto send_end;
	}
	unsigned char buf[MAXBUF+1];
	bzero(buf,MAXBUF+1);
	fseek(fp,0,SEEK_SET);
	while(1)
	{
		List * p = sendhead;          //创建一个指针指向头结点
		List * ptemp = NULL;      //创建一个占位节点
		if (p->next == NULL) {        //判断链表是否为空
			int read_num = fread((char*)(&buf), 1 , MAXBUF+1 , fp );//提取文件数据
			printf("\n");
			if ( read_num > 0)
			{
				if (0 == tcp_client.check_neartime(buf))
				{
					printf("发送补发数据\n");
					tcp_client.send_buftosend(buf);
				}
				fseek(fp,0,SEEK_CUR);
			}
			else if (0 == read_num)
			{
				printf("补发数据发送完成\n");
				fclose(fp);
				int ret = open("abnormal_save", O_WRONLY | O_TRUNC);
		        if(ret == -1)
		        {
	                printf("open file is fail!\n");
	                goto send_end;
		        }
		        printf("删除已补发数据！\n");
		        close(ret);
		        printf("返回实时数据上报\n");
				break;
			}
			else
			{
				printf("数据补发出现错误！\n");
				perror("reissue");
				fclose(fp);
				goto send_end;
			}
		}
	}
send_end: 
	pthread_exit(0);
}

/************************************************************
*func:		int check_neartime()
*param:		
*descrp:	检测数据包的时间是否是一周内的
*author:	Darren
*date:		2019.8.15
*ver:		v1.0.0
*change:
************************************************************/
int TCP_CLIENT::check_neartime(unsigned char buf[])
{
	//把报文时间换成tm格式
	struct tm _tm;
	time_t timep;
	_tm.tm_year = buf[24]+100;
	_tm.tm_mon = buf[25] - 1; 
	_tm.tm_mday = buf[26];
	_tm.tm_hour = buf[27];
	_tm.tm_min = buf[28];
	_tm.tm_sec = buf[29];
	timep = mktime(&_tm);
	//提取现在的时间
	time_t timer;
	time(&timer);
	int compare_time = timer - timep;
	//判断相差值是否小于一周的秒数
	if (compare_time <= 604800)
	{
		return 0;
	}
	else
	{
		return -1;
	}
}