#include "tcp_client.h"
extern int sockfd;

/************************************************************
*func:		send_log_upload()
*param:	
*descrp:	
*author:	Darren
*date:		2019.8.3
*ver:		v1.0.0
*change:
************************************************************/
void TCP_CLIENT::send_log_upload()
{
	unsigned char buf[MAXBUF];
	memcpy(buf,message_head(0x10),23*sizeof(char));
	//获取Unix时间戳
	time_t t;
	struct tm*lt;
	time (&t);
	lt = localtime(&t);
	buf[24] = lt->tm_year-100;
	buf[25] = lt->tm_mon+1;
	buf[26] = lt->tm_mday;
	buf[27] = lt->tm_hour;
	buf[28] = lt->tm_min;
	buf[29] = lt->tm_sec;//数据采集时间
	int i = 30;
	const char *s2 = "tcp://192.168.43.214:23666";
	memcpy(buf + i, s2, 26*sizeof(char));//拨号点名称
	i+=26;
	int buf_length = i+1;
	buf[23] =buf_length -25;//data_length
	int k;
	int BCC_code_resp=buf[0];
	for (k = 0; k < buf_length-2; k++)
   	{       
   		BCC_code_resp^=buf[k+1];
   	}
	buf[i] = BCC_code_resp;//BCC校验码
	send(sockfd, buf, MAXBUF, 0);
	printf("send upload message!\n");
}


/************************************************************
*func:		select_log_filename()
*param:		
*descrp:	select the log filename
*author:	Darren
*date:		2019.8.23
*ver:		v1.0.0
*change:
************************************************************/
int TCP_CLIENT::select_log_filename(char filename[])
{
	char choose[60];
	bzero(choose,60);
	printf("choose log type: [1]data_log  [2]error_log  [3]work_log  [4]all\n");
	cin>>choose;
	printf("input is %s\n",choose);
	if (!strcmp("1",choose)){
		printf("choose data log\n");
		const char *s1 = "log/data_log";
		memcpy(filename,s1,12*sizeof(char));
		select_log_day(filename);
	}
	else if (!strcmp("2",choose)){
		printf("error log\n");
		const char *s2 = "log/error_log";
		memcpy(filename,s2,13*sizeof(char));
		select_log_day(filename);
	}
	else if(!strcmp("3",choose)){
		const char *s3 = "log/work_log";
		memcpy(filename,s3,12*sizeof(char));
		select_log_day(filename);
	}
	else if(!strcmp("4",choose)){
		const char *s4 = "log.tar.gz";
		system("tar -czvf log.tar.gz log\n");
		memcpy(filename,s4,10*sizeof(char));
	}
	else{
		printf("choose1 input wrong\n");
		return(-1);
	}
}



/************************************************************
*func:		select_log_day()
*param:		
*descrp:	select the day of the log that needs to be uploaded
*author:	Darren
*date:		2019.8.23
*ver:		v1.0.0
*change:
************************************************************/
void TCP_CLIENT::select_log_day(char filename[])
{
	printf("choose day: [0]today  [1]1 day ago  [2]2 days ago  [3]3 days ago  [4]4 days ago  [5]5 days ago  [6]6 days ago\n");
	char choose2[60];
	bzero(choose2,60);
	cin>>choose2;
	int exist_num = strlen(filename);
	printf("exist_num: %d\n",exist_num);
	if(strcmp("0",choose2) == 0){
		printf("select today\n");
		const char *s0 = "/today";
		memcpy(filename+exist_num, s0, 6);
	}
	else if(strcmp("1",choose2) == 0){
		printf("select 1 day ago\n");
		const char *s1 = "/1dayago";
		memcpy(filename+exist_num, s1, 8);
	}
	else if(strcmp("2",choose2) == 0){
		printf("select 2 day ago\n");
		const char *s2 = "/2daysago";
		memcpy(filename+exist_num, s2, 9);
	}
	else if(strcmp("3",choose2) == 0){
		printf("select 3 day ago\n");
		const char *s3 = "/3daysago";
		memcpy(filename+exist_num, s3, 9);
	}
	else if(strcmp("4",choose2) == 0){
		printf("select 4 day ago\n");
		const char *s4 = "/4daysago";
		memcpy(filename+exist_num, s4, 9);
	}
	else if(strcmp("5",choose2) == 0){
		printf("select 5 day ago\n");
		const char *s5 = "/5daysago";
		memcpy(filename+exist_num, s5, 9);
	}
	else if(strcmp("6",choose2) == 0){
		printf("select 6 day ago\n");
		const char *s6 = "/6daysago";
		memcpy(filename+exist_num, s6, 9);
	}
	else{
		printf("choose2 input wrong\n");
	}
}


/************************************************************
*func:		void *process_tcp_upload()
*param:		void*upload_filename
*descrp:	start uploading
*author:	Darren
*date:		2019.8.23
*ver:		v1.0.0
*change:
************************************************************/
void *process_tcp_upload(void *uf)
{
	printf("enter upload pthread success\n");
	char upload_filename[60];
	memcpy(upload_filename, (char**)uf,60);
	printf("上传文件：%s\n",upload_filename);
	int local_sockfd;
	int upload_sockfd;
	if (-1 == 	tcp_client.create_upload_socket(local_sockfd,upload_sockfd))
	{
		printf("create upload socket wrong!\n");
	}
	tcp_client.tcp_upload(upload_sockfd,upload_filename);
	close(local_sockfd);
	close(upload_sockfd);
	printf("******************delete sockfd and exit pthread******************\n");
	pthread_exit(0);
}

/************************************************************
*func:		void create_upload_socket()
*param:
*descrp:	create socket for uploading
*author:	Darren
*date:		2019.8.23
*ver:		v1.0.0
*change:
************************************************************/
int TCP_CLIENT::create_upload_socket(int local_sockfd,int &upload_sockfd)
{
	//create sockfd
	if ((local_sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
	{
        perror("socket error");
        return(-1);
    }
	const int on = 1;
	setsockopt(local_sockfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));
	//bind ip and port
    struct sockaddr_in upload_addr;
	bzero(&upload_addr, sizeof(upload_addr));
    upload_addr.sin_family = AF_INET;
    upload_addr.sin_port = htons(23666);
    upload_addr.sin_addr.s_addr = inet_addr("192.168.43.214");
    if (bind(local_sockfd, (struct sockaddr*)&upload_addr, sizeof(upload_addr)) == -1)
	{
        perror("bind error");
        return(-1);
    }
	//socket_listen
	if (listen(local_sockfd, 5) == -1)
	{
        perror("listen error");
        return(-1);
    }
	printf("**************server has started up,waiting for connection******************\n");
	//accept
	struct sockaddr_in server_addr;
	socklen_t len = sizeof(server_addr);
	upload_sockfd =accept(local_sockfd, (struct sockaddr *)&server_addr, &len);
	if ( upload_sockfd == -1)
	{
		printf("fail connection\n");
		return(-1);
	}
	else
	{
		printf("connect success!\n");
		printf("upload_sockfd:%d\n", upload_sockfd);
		return(0);
	}
}

/************************************************************
*func:		void tcp_upload()
*param:
*descrp:	start to send log files
*author:	Darren
*date:		2019.8.23
*ver:		v1.0.0
*change:
************************************************************/
void TCP_CLIENT::tcp_upload(int s, char upload_filename[])
{
	printf("*****************start upload!***************\n");
	printf("upload_sockfd:%d\n", s);
	ssize_t size = 0;
	char buf[MAXBUF];
	int length=0;
	char buffer_add[MAXBUF]={'\0'};
	for(;;){
		size = read(s, buf, MAXBUF-length);
		if(size <= 0){
			printf("not read\n");
			return;
		}
		strcat(buffer_add, buf);
		length+=size;
		printf("recv:%d\n",length );
		if(length>=MAXBUF) break;
	}
	printf("%s\n", buffer_add); 
	bzero(buf, MAXBUF);
	memcpy(buf, upload_filename, 60);
	write(s, buf, MAXBUF);
	FILE *stream;
	if((stream=fopen(buf, "r"))==NULL) 
	{
		printf("file is not existing!\n");
		return;
	}
	printf("**************uploading****************\n");
	for(;;){
		size = fread(buf, sizeof(char), MAXBUF, stream);
		printf("%d\n", size);
		if(size <= 0){
			break;
		}
		write(s, buf, size);
	}
	fclose(stream);
	printf("**************upload success*************\n");
}