#include "tcp_client.h"
extern char *IP;
extern char *port;
//主函数
int main(int argc, char **argv)
{
	strcpy(IP,argv[1]);
	strcpy(port,argv[2]);
	tcp_client.set_socket(argc,argv);
	tcp_client.connect_socket(argv);
	pthread_t t1,t2,t3,t4;
	void *receive_message(void *);
	void *keyboard_send(void *);
	void *dispose_sendbuf(void *);
	void *dispose_recvbuf(void *);
	void *heartbeat();
	pthread_create(&t1,NULL,receive_message,(void*)0);
	pthread_create(&t2,NULL,keyboard_send,(void*)0);
	pthread_create(&t3,NULL,dispose_sendbuf,(void*)0);
	pthread_create(&t4,NULL,dispose_recvbuf,(void*)0);
	pthread_join(t1,NULL);
	pthread_join(t2,NULL);
	pthread_join(t3,NULL);
	pthread_join(t4,NULL);
	tcp_client.close_socket();
	exit(0);
}
