#ifndef _TCP_CLIENT_h
#define _TCP_CLIENT_h

#include <stdio.h> 
#include <string.h> 
#include <errno.h> 
#include <sys/socket.h> 
#include <resolv.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <time.h> 
#include <sys/time.h>
#include <unistd.h>
#include <stdbool.h>
#include <pthread.h>
#include <iostream>
#include <sys/stat.h>

#define MAXBUF 1024
#define domain_name_length_max 255

//初始化
using namespace std;
class TCP_CLIENT{
public:
	TCP_CLIENT();
	~TCP_CLIENT();
	void set_socket(int argc,char **argv);
	void connect_socket(char **argv);
	void send_buftosend(unsigned char []);
	void deal_buftosend();
	void send_recvbuf(unsigned char [],int);
	void deal_recvbuf();
	void begin_analyse(unsigned char[],int);
	int recvbuf_GetLength();
	void log_in();
	void log_out();
	void time_check();
	void code_check();
	unsigned char *data_create();
	void send_data(unsigned char[]);
	void data_save(unsigned char []);
	int data_getLength();
	void data_delete();
	void send_previous_data();
	void send_inquire(unsigned char[]);
	void modify_heartbeat_time();
	void set_parameter(unsigned char buffer2[]);
	void respond_modify_heartbeat(unsigned char[]);
	void respond_upgrade(unsigned char []);
	void write_parameter();
	int login_tcp(unsigned char []);
	int tcp_download(int );
	void client_restart();
	void heartbeat_send();
	int set_datasend_heartbeat(void);
	int close_socket();
	unsigned char command_check(unsigned char []);//检查命令标识
	void respond_set_parameter(unsigned char[]);
	int datasave_abnormal(unsigned char []);
	int save_error_log(char*);
	unsigned char *message_head(int);
	int check_neartime(unsigned char []);
	int select_log_filename(char []);
	void send_log_upload();
	int create_upload_socket(int,int&);
	void tcp_upload(int , char []);
protected:
	void get_recvbuf(int n);
	int analyse_single_packet(unsigned char []);
	int pick_single_packet(unsigned char [],int);
	unsigned long check_filesize(char buffer[]);
	void respond_login(unsigned char[]);
	void respond_logout(unsigned char[]);
	void respond_time(unsigned char[]);
	void respond_data(unsigned char[]);
	void respond_heartbeat(unsigned char[]);
	void respond_inquire(unsigned char[]);
	void respond_reissue(unsigned char[]);
	bool BCC_check(unsigned char []);
	void select_log_day(char []);
};

static int dcmi_sol_pthread_attr_init(pthread_attr_t *);
static void dcmi_sol_pthread_attr_destroy(pthread_attr_t *);
static void datasend_timeout(union sigval v);
static void heartbeat_timeout(union sigval v);

class Log
{
public:
	Log();
	~Log();
	void save_normal_log(unsigned char []);
protected:
	int save_log_login(unsigned char []);
	int save_log_logout(unsigned char []);
	int save_log_data(unsigned char []);
	int save_log_upgrade(unsigned char []);
private:
	void select_worklog_filename(struct tm);
	void select_datalog_filename(struct tm);
	int buf_length;
};

typedef struct
{	uint16_t time_period;
	uint16_t normal_time_period;
	uint16_t alarm_time_period;
	uint8_t  domain_name_length;
	unsigned char domain_name [domain_name_length_max];
	uint16_t tcp_port;
	uint8_t hardware_version [6];
	uint8_t firmware_version [6];
	uint8_t heartbeat_send_period;
	uint16_t respond_overtime_time;
	uint16_t platform_overtime_time;	
	uint8_t gap_login_time;
	uint8_t common_domain_name_length;
	unsigned char common_domain_name [domain_name_length_max];
	uint16_t common_tcp_port;
	uint8_t sampling_inspection;
}parameter;//参数

struct List
{	unsigned char tcp_data[MAXBUF+1];
	List *next;
};
struct SList
{	unsigned char recv_data[MAXBUF+1];
	int recv_len;
	SList *next;
};

void test1();
void test2();
void test3();
void test4();
void test5();
void test6();

extern TCP_CLIENT tcp_client;
#endif