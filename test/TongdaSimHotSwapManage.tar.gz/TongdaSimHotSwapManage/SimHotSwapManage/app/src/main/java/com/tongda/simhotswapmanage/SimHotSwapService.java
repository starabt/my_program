package com.tongda.simhotswapmanage;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.EthernetManager;
import android.net.NetworkInfo;
import android.net.NetworkManager;
import android.os.IBinder;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;


public class SimHotSwapService extends Service {
    private static final String TAG = "SimHotSwapService";
    private IntentFilter intentFilter;
    private SimStateReceive simStateReceive;
    private  boolean simStateReceiveRegister = false;

    private  boolean mBooted = false;   /*系统启动标志*/
    private  int mLastSimStatus = -1;   /*上一次SIM卡消息*/
    private  int mNewSimStatus = -1;    /*当前SIM卡消息*/

    private  boolean networkRecoveryFlag = false;   /*飞行模式已设置标志*/ /*NO use*/

    private NetworkManager networkManager;
    private int tryTime = 0;/*以太网获取IP限制次数*/

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public void onCreate() {
        if(fileIsExists("/dev/ttyUSB1")) {
            /*注册广播接收SIM卡消息*/
            intentFilter = new IntentFilter();
            intentFilter.addAction("android.intent.action.SIM_STATE_CHANGED");
            simStateReceive = new SimStateReceive();
            registerReceiver(simStateReceive, intentFilter);
            simStateReceiveRegister = true;
            Log.d(TAG, "onCreate: start SimStateReceive...");
            
            /*移动网络监控线程*/
            new Thread(new Runnable() {
                @Override
                public void run() {
                    simManageThread();
              }
            }).start();
        }
        else{
            Log.d(TAG, "onCreate: 4G module don't exist.");
        }

        /*以太网监控线程*/
        networkManager = new NetworkManager();
        networkManager.enableEthManager(SimHotSwapService.this);
        new Thread(new Runnable() {
            @Override
            public void run() {
                netrworkManageThread();
            }
        }).start();

        super.onCreate();
    }

    @Override
    public void onDestroy() {
        if(simStateReceiveRegister) {
            unregisterReceiver(simStateReceive);
        }
        super.onDestroy();
    }

    /*移动网络监控线程*/
    public void simManageThread(){
        while (true) {
            int networkType = isNetworkConnected(SimHotSwapService.this);
            if(networkType == ConnectivityManager.TYPE_MOBILE){
                //Log.d(TAG, "simManageThread: mobile connect...");
            }
            else{
                //Log.d(TAG, "simManageThread: no connect, type:"+networkType);
                /*if(networkRecoveryFlag)*/{
                    try {
                        Thread.currentThread().sleep(120 * 1000);//2分钟
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    /* 重新获取连接状态，以免在此时间内断开了以太网或WIFI */
                    networkType = isNetworkConnected(SimHotSwapService.this);
                    /*网络恢复成功*/
                    if(networkType == ConnectivityManager.TYPE_MOBILE){
                        continue;
                    }

                    /*网络恢复失败，超时后再次恢复移动网络*/
                    recoveryMobileNetwork();
                    //networkRecoveryFlag = false;//仅重设一次，若联网还失败不再进行处理
                }
            }
            try {
                Thread.currentThread().sleep(60 * 1000);//1分钟获取一次网络状态
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    /*获取网络连接状态*/
    public static int isNetworkConnected(Context context) {
        ConnectivityManager manager = (ConnectivityManager) context.getSystemService(
                        Context.CONNECTIVITY_SERVICE);

        if (manager == null) {
            return -1;
        }

        NetworkInfo networkinfo = manager.getActiveNetworkInfo();
        if (networkinfo == null || !networkinfo.isAvailable()) {
            return -1;
        }

        return networkinfo.getType();
    }

    public class SimStateReceive extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            /*接收SIM卡状态广播*/
            simManger();
        }
    }

    public boolean fileIsExists(String strFile) {
        try {
            File f = new File(strFile);
            if (!f.exists()) {
                return false;
            }
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    /*飞行模式控制接口*/
    public boolean turnOnOffAirplaneMode(boolean isTurnOn) {
        boolean result = true;
        try {
            Settings.Global.putInt(getContentResolver(),
                    Settings.Global.AIRPLANE_MODE_ON, isTurnOn ? 1 : 0);
            Intent intent = new Intent(Intent.ACTION_AIRPLANE_MODE_CHANGED);
            intent.putExtra("state", isTurnOn);
            sendBroadcast(intent);
            Log.d(TAG, "turnOnOffAirplaneMode: "+ isTurnOn);
        } catch (Exception e) {
            result = false;
        }
        return result;
    }

    /*通过控制飞行模式恢复移动网络*/
    private  void recoveryMobileNetwork(){
        /* 网络优先级 以太网>WIFI>4G */
        /*移动网络优先级最低，若以太网或WIFI已连接，不进行移动网络恢复*/
        int networkType = isNetworkConnected(SimHotSwapService.this);
        if(networkType == ConnectivityManager.TYPE_WIFI || networkType == ConnectivityManager.TYPE_ETHERNET)
            return;

        turnOnOffAirplaneMode(true);
        try {
            Thread.currentThread().sleep(1000);//毫秒
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        turnOnOffAirplaneMode(false);
    }

    /*SIM控制逻辑*/
    private void simManger(){
        TelephonyManager tm = (TelephonyManager)getSystemService(Service.TELEPHONY_SERVICE);
        mNewSimStatus = tm.getSimState();
        Log.d(TAG, "onReceive: mNewSimStatus:"+ mNewSimStatus);

        if(mLastSimStatus == mNewSimStatus) {
            return;
        }

        mLastSimStatus = mNewSimStatus;
        switch (mNewSimStatus) {
            case TelephonyManager.SIM_STATE_UNKNOWN :
            case TelephonyManager.SIM_STATE_ABSENT :
                if(mBooted) {
                    recoveryMobileNetwork();
                }
                else{
                    mBooted = true;
                }
				//networkRecoveryFlag = true;
                break;
            case TelephonyManager.SIM_STATE_READY :
                //networkRecoveryFlag = false;
                break;
            case TelephonyManager.SIM_STATE_NOT_READY :
                /* SIM卡状态改变，恢复移动网络*/
                recoveryMobileNetwork();
                //networkRecoveryFlag = true;
                break;
            case TelephonyManager.SIM_STATE_PIN_REQUIRED :
            case TelephonyManager.SIM_STATE_PUK_REQUIRED :
            case TelephonyManager.SIM_STATE_NETWORK_LOCKED :
            case TelephonyManager.SIM_STATE_PERM_DISABLED :
            case TelephonyManager.SIM_STATE_CARD_IO_ERROR :
            //case TelephonyManager.SIM_STATE_CARD_RESTRICTED :
            case 9:
            default:
                break;
        }
    }


    /**
     * 以太网插入后dhcp获取IP失败处理线程
     */
    public void netrworkManageThread() {
        int ethConnect = -1;//以太网插入标志，1：插入，0：未插入

        while (true) {
            ethConnect = isEthernetConnect();
            //Log.d(TAG, "run: " + ethConnect);
            try {
                Thread.currentThread().sleep(60 * 1000);//1分钟检测一次网线是否插入
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            /*网线没有插入,计数清零*/
            if(ethConnect == 0) {
                tryTime = 0;
                continue;
            }else {
                try {
                    Thread.currentThread().sleep(120 * 1000);//检测到网线已插入，延时2分钟再获取IP状态
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                if(isIpEampty()) {
                    /*没有获取到IP地址，以太网开关操作限制在10次，约30分钟*/
                    /*取消限制 20190611*/
/*                    tryTime++;
                    if(tryTime >= 10)
                        continue;*/
                    Log.d(TAG, "start reopen ethernet switch");
                    networkManager.closeEthernet(SimHotSwapService.this);
                    try {
                        Thread.currentThread().sleep(2 * 1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    networkManager.openEthernet(SimHotSwapService.this);
                }
            }
        }
    }


    /**
     * @return true:eth0 ip 为空，false：IP 不为空
     */
    public boolean isIpEampty() {
        String ipAddress = "0.0.0.0";  //IP
        String err = "error";

        ipAddress = NetworkUtil.getIpAddrForInterfaces("eth0");
        if(ipAddress.compareTo(err) == 0) {
            //Log.d(TAG, "isIpEampty: IP is empty");
            return true;
        }else {
            //Log.d(TAG, "isIpEampty: IP is not empty,ip = " + ipAddress);
            return false;
        }
    }



    /**
     * 检测网线是否插入
     * @return true:网线已插入；false：网线没有插入
     */
    public int isEthernetConnect() {
        Runtime mRuntime = Runtime.getRuntime();
        try {
            Process mProcess = mRuntime.exec("cat /sys/class/net/eth0/carrier");
            BufferedReader mReader = new BufferedReader(new InputStreamReader(mProcess.getInputStream()));
            StringBuffer mRespBuff = new StringBuffer();
            char[] buff = new char[1024];
            int ch = 0;
            while ((ch = mReader.read(buff)) != -1) {
                mRespBuff.append(buff, 0, ch);
            }
            mReader.close();
            //Log.d(TAG, "isEthernetConnect: " + mRespBuff.toString());

            StringBuffer strbuf = new StringBuffer("1\n");
            if(mRespBuff.toString().equals(strbuf.toString()))
            {
                return 1;
            }else {
                return 0;
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return -1;
        }
    }

}
