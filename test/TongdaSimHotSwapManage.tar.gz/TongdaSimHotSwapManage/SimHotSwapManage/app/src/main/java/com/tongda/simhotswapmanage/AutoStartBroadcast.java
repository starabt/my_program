package com.tongda.simhotswapmanage;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/**
 * Created by lww on 2019-1-22.
 */

public class AutoStartBroadcast extends BroadcastReceiver {
    static final String ACTION = "android.intent.action.BOOT_COMPLETED";
    private static final String TAG = "AutoStartBroadcast";
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals(ACTION)) {

            /*启动activity*/
            /*
            Intent mainActivityIntent = new Intent(context, MainActivity.class);  // 要启动的Activity
            mainActivityIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(mainActivityIntent);
            Log.d(TAG, "onReceive: auto start MainActivity...");
            */

            /* 启动服务程序*/
            Log.d(TAG, "onReceive: start SimHotSwapService...");
            Intent mBootIntent = new Intent(context, SimHotSwapService.class);
            context.startService(mBootIntent);
        }
    }
}
