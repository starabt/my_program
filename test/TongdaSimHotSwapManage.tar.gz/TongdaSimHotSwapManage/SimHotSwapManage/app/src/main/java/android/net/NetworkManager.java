package android.net;

import android.content.ContentResolver;
import android.content.Context;
import android.provider.Settings.System;
import android.util.Log;


import com.tongda.simhotswapmanage.NetworkUtil;

import java.net.Inet4Address;
import java.net.InetAddress;

/**
 * Created by Zhou Jinlong on 2018/7/31.
 */
public class NetworkManager {
    private static final String TAG = "NetworkManager";
    private EthernetManager mEthManager;
    private String mEthIpAddress = "192.168.88.111";  //IP
    private String mEthNetmask = "255.255.255.0";  //  子网掩码
    private String mEthGateway = "192.168.88.1";   //网关
    private String mEthdns1 = "8.8.8.8";   // DNS1
    private String mEthdns2 = "8.8.4.4";   // DNS2

    private StaticIpConfiguration mStaticIpConfiguration;

    private IpConfiguration mIpConfiguration;

    public boolean setStaticIpConfiguration(Context context, String ip, String mask, String gate, String dns1, String dns2) {

        mEthIpAddress = ip;
        mEthNetmask = mask;
        mEthGateway = gate;
        mEthdns1 = dns1;
        mEthdns2 = dns2;

        mStaticIpConfiguration = new StaticIpConfiguration();
        /*
         * get ip address, netmask,dns ,gw etc.
         */
        Inet4Address inetAddr = NetworkUtil.getIPv4Address(this.mEthIpAddress);
        int prefixLength = NetworkUtil.maskStr2InetMask(this.mEthNetmask);
        InetAddress gatewayAddr = NetworkUtil.getIPv4Address(this.mEthGateway);
        InetAddress dnsAddr = NetworkUtil.getIPv4Address(this.mEthdns1);

        if (inetAddr.getAddress().toString().isEmpty() || prefixLength == 0 || gatewayAddr.toString().isEmpty()
                || dnsAddr.toString().isEmpty()) {
            log("ip,mask or dnsAddr is wrong");
            return false;
        }

        String dnsStr2 = this.mEthdns2;
        mStaticIpConfiguration.ipAddress = new LinkAddress(inetAddr, prefixLength);
        mStaticIpConfiguration.gateway = gatewayAddr;
        mStaticIpConfiguration.dnsServers.add(dnsAddr);

        if (!dnsStr2.isEmpty()) {
            mStaticIpConfiguration.dnsServers.add(NetworkUtil.getIPv4Address(dnsStr2));
        }
        mIpConfiguration = new IpConfiguration(IpConfiguration.IpAssignment.STATIC, IpConfiguration.ProxySettings.NONE, mStaticIpConfiguration, null);

        enableEthManager(context);

        if (mEthManager != null) {
            mEthManager.setConfiguration(mIpConfiguration);
            saveIpSettingInfo(context, true, ip, mask, gate, dns1, dns2);
        }

        return true;
    }

    public void saveIpSettingInfo(Context context, boolean useStaticIp, String ip, String mask, String gate, String dns1, String dns2) {
        int useStaticIpInt;
        if (useStaticIp) {
            useStaticIpInt = 1;
        } else {
            useStaticIpInt = 0;
        }
        ContentResolver contentResolver = context.getContentResolver();
        System.putInt(contentResolver, System.ETHERNET_USE_STATIC_IP, useStaticIpInt);
        System.putString(contentResolver, System.ETHERNET_STATIC_IP, ip);
        System.putString(contentResolver, System.ETHERNET_STATIC_GATEWAY, gate);
        System.putString(contentResolver, System.ETHERNET_STATIC_NETMASK, mask);
        System.putString(contentResolver, System.ETHERNET_STATIC_DNS1, dns1);
        System.putString(contentResolver, System.ETHERNET_STATIC_DNS2, dns2);
    }

    private void log(String s) {
        Log.d(TAG, s);
    }

    public void openEthernet(Context context) {
        //enableEthManager(context);
        if (mEthManager != null) {
            mEthManager.setEthernetEnabled(true);
        }
    }

    public void closeEthernet(Context context) {
        //enableEthManager(context);
        if (mEthManager != null) {
            mEthManager.setEthernetEnabled(false);
        }
    }

    public void setDhcpMode(Context context) {
        enableEthManager(context);
        mEthManager.setConfiguration(new IpConfiguration(IpConfiguration.IpAssignment.DHCP, IpConfiguration.ProxySettings.NONE, null, null));
    }

    public void enableEthManager(Context context) {
        if (mEthManager == null) {
            mEthManager = (EthernetManager) context.getSystemService("ethernet");
        }
    }

}
